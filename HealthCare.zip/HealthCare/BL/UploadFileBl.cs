﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using HealthCare.Data;
using HealthCare.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

//using static XPassApplication.Data.Common;


namespace HealthCare.BL
{
    public class UploadFileBl :ControllerBase
    {

        
        #region uploadFile
        public static async Task<string> uploadFile(IFormFile formFile)
        {
            try
            {

                string[] strFilename = Regex.Replace(formFile.FileName, @"[^.0-9a-zA-Z]+", "").Split('.');
                string Filename = strFilename[0] + "_" + DateTime.Now.ToString("dd'-'MM'-'yyyy'-'HH'-'mm'-'ss") + "." + strFilename[1];
                   
                var uploadRequest = new TransferUtilityUploadRequest
                    {
                       InputStream = formFile.OpenReadStream(),
                       Key = Filename,
                       BucketName = "healthcarecontent", 
                       CannedACL = S3CannedACL.PublicRead
                    };
                    var fileTransferUtility = new TransferUtility("AKIAJMRJERAX5PJA5QPA", "wQdolNAEcwN5ozWVaTKZhqZIY+iIVSyP0DgbnY8M", RegionEndpoint.USEast1);
                    await fileTransferUtility.UploadAsync(uploadRequest);
                  
                    return "https://healthcarecontent.s3-us-west-2.amazonaws.com/" + Filename;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #region uploadFileFrom File path
        public static async Task<string> uploadFileFromPath(string filename)
        {
            try
            {

                string path = Path.GetFullPath(filename);

                var uploadRequest = new TransferUtilityUploadRequest
                {
                    FilePath= path,
                    Key = filename,
                    BucketName = "healthcarecontent",
                    CannedACL = S3CannedACL.PublicRead
                };
                var fileTransferUtility = new TransferUtility("AKIAJMRJERAX5PJA5QPA", "wQdolNAEcwN5ozWVaTKZhqZIY+iIVSyP0DgbnY8M", RegionEndpoint.USEast1);
                await fileTransferUtility.UploadAsync(uploadRequest);

                return "https://healthcarecontent.s3-us-west-2.amazonaws.com/" + filename;


            }

            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion


        //#region Generate file
        //public static string GenerateFile(string filename)
        //{
        //    try
        //    {
        //        ////Create a new PDF document.
        //        //PdfDocument doc = new PdfDocument();
        //        ////Add a page to the document.
        //        //PdfPage page = doc.Pages.Add();

        //        ////Save the document.
        //        //doc.Save("Output.pdf");
        //        ////Close the document.
        //        //doc.Close(true);

        //        ConversionOptions options = new ConversionOptions(PageSize.A4, PageOrientation.Portrait, 50.0f);
        //        // Set Metadata for the PDF
        //        options.Author = "Myself";
        //        options.Title = "My Webpage";
        //        // Set Header and Footer text
        //        options.Header = "<div style=\"text-align:center;display:inline-block;width:100%;font-size:12px;\">" +
        //            "<span class=\"date\"></span></div>";
        //        options.Footer = "<div style=\"text-align:center;display:inline-block;width:100%;font-size:12px;\">" +
        //            "Page <span class=\"pageNumber\"></span> of <span class=\"totalPages\"></span></div>";
        //        // Convert with Options          
        //        Converter.Convert(new Uri("https://www.google.com"), filename, options);

        //        return "";
        //    }

        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}

        //#endregion

    }
}
