﻿using HealthCare.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.BL
{
    public class DrugsBL
    {

        public static dynamic listMedicineDetails(int userId,string search,int count,int offset)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@search", search ?? ""));
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetMedicine", parameters);

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        } 

        public static dynamic getDrugInteractionById(int userId)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetDrugInteraction", parameters);                

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic listUserMedicineDetails(int userId)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));


                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserMedicineDetails", parameters);
                
                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getPDFUserMedicinReport(int userId)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));


                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserDrugAndInteraction", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic SaveMedicineDetails(SaveMedicine theobj)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", theobj.userId));
                parameters.Add(new SqlParameter("@medicineDetails", theobj.medicineDetails));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveMedicineDetails", parameters);

                return new { message = "Success" };


            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getAttributes()
        {
            try
            {
                DataTable dt = HealthCare.Data.DbConnection.GetData("spGetAttributes");
                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getDiseaseResult(string possiblevalues)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@possiblevalues", possiblevalues));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetDiseaseResult", parameters);
                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getPDFUserMedicinReport(int userId)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));


                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserDrugAndInteraction", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
