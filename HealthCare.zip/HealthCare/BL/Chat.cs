﻿using HealthCare.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace HealthCare.BL
{
    public class Chat
    {
        public static dynamic createChat(createChat createChat)
        {
            try
            {
                string content = "sent a new friend request";  // if anything changes make here,also change the content spCreateChat also.
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", createChat.userId));
                parameters.Add(new SqlParameter("@contactUserId", createChat.contactUserId));
                parameters.Add(new SqlParameter("@content", content));

                DataSet ds = HealthCare.Data.DbConnection.save("spCreateChat", parameters);
                string result = ds.Tables[0].Rows[0]["message"].ToString();
                if (result == "Success")
                {

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();

                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = "Hi, " + ds.Tables[1].Rows[i]["userName"].ToString() + " " + content + "\n" +
                                   "لديك طلب اتصال جديد";           
                                   PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic CreateGroup(CreateGroup createGroup)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", createGroup.userId));
                parameters.Add(new SqlParameter("@groupName", createGroup.groupName));
                parameters.Add(new SqlParameter("@groupIcon", createGroup.groupIcon));
                parameters.Add(new SqlParameter("@groupMemberId", createGroup.groupMemberId));

                DataSet ds = HealthCare.Data.DbConnection.save("spCreateGroup", parameters);

                string result = ds.Tables[0].Rows[0]["message"].ToString();
                int groupId = (int)ds.Tables[0].Rows[0]["groupId"];

                if (result == "Success")
                {

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();

                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = ds.Tables[1].Rows[i]["content"].ToString();
                                PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result, groupId = groupId };

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic AddGroupMembers(AddGroupMembers addGroupMembers)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@groupId", addGroupMembers.groupId));
                parameters.Add(new SqlParameter("@groupMemberId", addGroupMembers.groupMemberId));

                DataSet ds = HealthCare.Data.DbConnection.save("spAddGroupMembers", parameters);

                string result = ds.Tables[0].Rows[0]["message"].ToString();
                if (result == "Success")
                {

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();

                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = ds.Tables[1].Rows[i]["content"].ToString();
                                PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result };


            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic UpdateSingleUserChatStatus([FromBody]UpdateUserChatStatus updateUserChatStatus)
        {
            try
            {

                string content = updateUserChatStatus.status + " your friend request.";  // if anything changes make here,also change the content spUpdateUserChatStatus also.
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", updateUserChatStatus.userId));
                parameters.Add(new SqlParameter("@contactUserId", updateUserChatStatus.contactUserId));
                parameters.Add(new SqlParameter("@status", updateUserChatStatus.status));
                parameters.Add(new SqlParameter("@chatType", "Single"));
                parameters.Add(new SqlParameter("@content", content));

                DataSet ds = HealthCare.Data.DbConnection.save("spUpdateUserChatStatus", parameters);

                string result = ds.Tables[0].Rows[0]["message"].ToString();
                if (result == "Success")
                {

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();

                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = "Hi," + ds.Tables[1].Rows[i]["userName"].ToString() + " " + content;
                                PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic UpdateGroupUserChatStatus([FromBody]UpdateUserChatStatus updateUserChatStatus)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", updateUserChatStatus.userId));
                parameters.Add(new SqlParameter("@contactUserId", updateUserChatStatus.contactUserId));
                parameters.Add(new SqlParameter("@status", updateUserChatStatus.status));
                parameters.Add(new SqlParameter("@chatType", ""));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spUpdateUserChatStatus", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic DeleteSingleContactList([FromBody]DeleteContactList deleteContactList)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", deleteContactList.userId));
                parameters.Add(new SqlParameter("@contactUserId", deleteContactList.contactUserId));

                parameters.Add(new SqlParameter("@chatType", "Single"));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeleteContactList", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic DeleteGroupContactList([FromBody]DeleteContactList deleteContactList)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", deleteContactList.userId));
                parameters.Add(new SqlParameter("@contactUserId", deleteContactList.contactUserId));

                parameters.Add(new SqlParameter("@chatType", ""));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeleteContactList", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic DeleteGroup([FromBody]DeleteGroup deleteGroup)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", deleteGroup.userId));
                parameters.Add(new SqlParameter("@groupId", deleteGroup.groupId));



                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeleteGroup", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic ListChatList(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spListChatList", parameters);

                return dt;
            }

            catch (Exception e)
            {
                throw e;
            }

        }

        public static dynamic sendMessage(SendMessage sendMessage)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@chatType", sendMessage.chatType));
                parameters.Add(new SqlParameter("@referenceId", sendMessage.referenceId));
                parameters.Add(new SqlParameter("@messageContent", sendMessage.messageContent));
                parameters.Add(new SqlParameter("@mediaContent", sendMessage.mediaContent));
                parameters.Add(new SqlParameter("@parentId", sendMessage.parentId == 0 ? null : sendMessage.parentId));

                DataSet ds = HealthCare.Data.DbConnection.save("spSendMessage", parameters);
                if(ds.Tables[0].Rows.Count >0)
                {
                    if (ds.Tables[0].Rows[0]["message"].ToString() == "You are not eligible to send a message until they accept your request")
                    {
                        return "You are not eligible to send a message until they accept your request \n  لست مؤهلاً لإرسال رسالة حتى يقبل المستخدم دعوتك";
                    }
                    else if (ds.Tables[0].Rows[0]["message"].ToString() == "Success")
                    {
                        var cTask = Task.Run(() => sendmsg(ds.Tables[0]));

                        return ds.Tables[1];
                    }
                }

                   return ds.Tables[1];

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static void sendmsg(DataTable dt)
        {

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                PushNotification pushNotification = new PushNotification();
                pushNotification.Title = dt.Rows[i]["name"].ToString() ?? "";
                pushNotification.Body = dt.Rows[i]["messageContent"].ToString() ?? "";
                pushNotification.DeviceId = dt.Rows[i]["firebaseRegID"].ToString() ?? "";
                PushNotificationsBL.pushNotification(pushNotification);
            }
        }
        public static dynamic DeleteMessage(int chatMessageId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@chatMessageId", chatMessageId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeleteMessage", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic ListSingleChatMessage(int userId, int chatcontactId, string search)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@chatcontactId", chatcontactId));
                parameters.Add(new SqlParameter("@search", search ?? ""));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spListSingleChatMessage", parameters);

                return dt;
            }

            catch (Exception e)
            {
                throw e;
            }

        }


        public static dynamic ListGroupChatMessage(int userId, int groupId, string search)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@groupId", groupId));
                parameters.Add(new SqlParameter("@search", search ?? ""));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spListGroupChatMessage", parameters);

                return dt;
            }

            catch (Exception e)
            {
                throw e;
            }

        }
        public static dynamic getGroupList(int groupId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@groupId", groupId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGroupList", parameters);


                return dt;
            }

            catch (Exception e)
            {
                throw e;
            }

        }



        public static dynamic sharePost(SharePost sharePost)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@contactId", sharePost.contactId));
                parameters.Add(new SqlParameter("@messageContent", sharePost.messageContent));
                parameters.Add(new SqlParameter("@mediaContent", sharePost.mediaContent));
                parameters.Add(new SqlParameter("@isAllowPublic", sharePost.isAllowPublic));

                DataSet ds = HealthCare.Data.DbConnection.save("spSharePost", parameters);
                string result = ds.Tables[0].Rows[0]["message"].ToString();
                if (result == "Success")
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        var cTask = Task.Run(() => sendLinkedInNotification(ds.Tables[1]));
                        return new { message = result };
                    }
                }

                return new { message = result };
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static void sendLinkedInNotification(DataTable dt)
        {
            try
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    PushNotification objpush = new PushNotification();
                    objpush.DeviceId = dt.Rows[i]["firebaseRegId"].ToString();
                    objpush.Body = dt.Rows[i]["content"].ToString();
                    PushNotificationsBL.pushNotification(objpush);

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }



        public static dynamic LikePost(LikePost likePost)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@linkedInPostId", likePost.linkedInPostId));
                parameters.Add(new SqlParameter("@chatcontactId", likePost.chatcontactId));
                parameters.Add(new SqlParameter("@isLiked", likePost.isLiked));

                DataSet ds = HealthCare.Data.DbConnection.save("spLikePost", parameters);
                string result = ds.Tables[0].Rows[0]["message"].ToString();

                if (result == "Success")
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();
                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = ds.Tables[1].Rows[i]["content"].ToString();
                                PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic commentPost(commentPost commentPost)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@linkedInPostId", commentPost.linkedInPostId));
                parameters.Add(new SqlParameter("@chatcontactId", commentPost.chatcontactId));
                parameters.Add(new SqlParameter("@comments", commentPost.comments));
                parameters.Add(new SqlParameter("@mediaContent", commentPost.mediaContent));
                parameters.Add(new SqlParameter("@parentId", commentPost.parentId == 0 ? null : commentPost.parentId));

                DataSet ds = HealthCare.Data.DbConnection.save("spcommentPost", parameters);

                string result = ds.Tables[0].Rows[0]["message"].ToString();

                if (result == "Success")
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            PushNotification objpush = new PushNotification();
                            {
                                objpush.DeviceId = ds.Tables[1].Rows[i]["firebaseRegId"].ToString();
                                objpush.Body = ds.Tables[1].Rows[i]["content"].ToString();
                                PushNotificationsBL.pushNotification(objpush);
                            }
                        }
                    }

                }

                return new { message = result };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic ListPost(int contactId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@contactId", contactId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spListPost", parameters);

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getUserPost(int contactId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@contactId", contactId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetuserPost", parameters);

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic ListComment(int linkedInPostId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@linkedInPostId", linkedInPostId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spListComments", parameters);

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getUserList(int userId, string search)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@search", search ?? ""));

                DataSet ds = HealthCare.Data.DbConnection.save("spgetUserList", parameters);

                return ds.Tables[0];
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic ListContactList(int userId, int groupId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@groupId", groupId > 0 ? groupId : 0));

                DataSet ds = HealthCare.Data.DbConnection.save("spListContactList", parameters);

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }

        }
        public static dynamic DeletePost(int linkedInPostId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@linkedInPostId", linkedInPostId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeletePost", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic ViewPost(ViewPost viewPost)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@linkedInPostId", viewPost.linkedInPostId));
                parameters.Add(new SqlParameter("@userId", viewPost.userId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spViewPost", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic ViewPostComments(ViewPostComment viewPostComment)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@postCommentId", viewPostComment.postCommentId));
                parameters.Add(new SqlParameter("@userId", viewPostComment.userId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spViewPostComments", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic clearChatNotification(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spClearChatNotification", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getChatNotification(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetChatNotification", parameters);
                DataTable dtNotificationList = ds.Tables[0];
                int notificationCount = (int)ds.Tables[1].Rows[0]["chatCount"];
                var result = new { notificationCount = notificationCount, notificationList = dtNotificationList };
                return result;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic ViewProfile(ViewProfile viewProfile)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@viewedUserId", viewProfile.viewedUserId));
                parameters.Add(new SqlParameter("@userId", viewProfile.userId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spViewProfile", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic GetViewProfileUsers(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetViewProfileUsers", parameters);

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


    }
}