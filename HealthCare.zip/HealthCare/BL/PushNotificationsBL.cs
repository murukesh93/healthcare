﻿using HealthCare.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HealthCare.BL
{
    public class PushNotificationsBL
    {
        public static dynamic pushNotification(PushNotification pushNotification)
        {

            try
            {
                string SERVER_API_KEY = "AAAAPCPvmx8:APA91bFhRG80XsnftE5qquGXntMwRd8KMFvg0GTvrUCDV6ptn03l821Pbweqay6ClVzoJsLl18HO7qS3w_EdGUO9-tXppjVAEjPygpy_jf5I0n6gCHgzN5yiIciYBXk3kQZfwv1GrUqs";
                var SENDER_ID = "258300943135";


                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", SERVER_API_KEY));
                tRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));
                tRequest.ContentType = "application/json";
                var payload = new
                {
                    to = pushNotification.DeviceId,
                    priority = "high",
                    content_available = true,
                    sound = "default",
                  
                    notification = new
                    {
                        title = pushNotification.Title,
                        body = pushNotification.Body,
                    },
                    
                    data = new { click_action = "FLUTTER_NOTIFICATION_CLICK" , notificaionId = pushNotification.NotificaionId, }

                };

                var json = JsonSerializer.Serialize(payload);

                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.ContentLength = byteArray.Length;

                Stream dataStream = tRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                WebResponse tResponse = tRequest.GetResponse();
                dataStream = tResponse.GetResponseStream();
                StreamReader tReader = new StreamReader(dataStream);
                String sResponseFromServer = tReader.ReadToEnd();

                tReader.Close();
                dataStream.Close();
                tResponse.Close();
                    JObject o = JObject.Parse(@sResponseFromServer);
                JToken msg = o.SelectToken("$.['success']");
                if (Convert.ToInt32(msg) == 1)
                {
                    return "Notification Send Successfully";
                }
                else
                {
                    return sResponseFromServer;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getNotification(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetNotification", parameters);
                
                return dt;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic ReadNotification(int notificationId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@notificationId", notificationId));
                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveRemainderNotification", parameters);

                return dt.Rows[0][0].ToString();
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic UserNotificationCount(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetUserNotificationCount", parameters);
                return new { userNotificationCount = dt.Rows[0]["notificationCount"] };

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic ConfirmRemainder(int notificationId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@notificationId", notificationId));
                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spConfirmRemainder", parameters);

                return dt.Rows[0][0].ToString();
            }

            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
