﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using HealthCare.Data;
using HealthCare.Model;

namespace HealthCare.BL
{
    public class LoginBL
    {
        #region GenerateJSONWebToken
        public static string GenerateJSONWebToken()  //Login userInfo
        {
            var JwtKey = Common.GetConnectionString("Jwt", "Key");
            var JwtIssuer = Common.GetConnectionString("Jwt", "Issuer");

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtKey));

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(JwtIssuer,
            JwtIssuer,
            null,
            signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
            
        }
        #endregion

        #region GetUserLogin
        public static dynamic login([FromBody]Login login)
        {
            List<dynamic> userdetails = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Email", login.email));
                parameters.Add(new SqlParameter("@Password", login.password));

                DataSet ds = DbConnection.save("spLogin", parameters);
                DataTable dt = ds.Tables[0];
                dynamic user = new System.Dynamic.ExpandoObject();

                if (dt.Rows.Count > 0)
                {
                    user.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    user.name = dt.Rows[0]["name"].ToString() ?? "";
                    user.phoneNumber = dt.Rows[0]["phoneNumber"].ToString() ?? "";
                    user.email = dt.Rows[0]["email"].ToString() ?? "";
                    user.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    user.gender = dt.Rows[0]["gender"].ToString() ?? "";
                    user.height = dt.Rows[0]["height"].ToString() ?? "";
                    user.weight = dt.Rows[0]["weight"].ToString() ?? "";
                    user.dob = dt.Rows[0]["dob"].ToString() ?? "";
                    user.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    user.countryId = (int?)dt.Rows[0]["countryId"] ?? 0;
                    user.countryName = dt.Rows[0]["countryName"].ToString() ?? "";
                    user.code = dt.Rows[0]["code"].ToString() ?? "";
                    user.bloodGroupId = (int?)dt.Rows[0]["bloodGroupId"] ?? 0;
                    user.bloodGroupName = dt.Rows[0]["bloodGroupName"].ToString() ?? "";
                    var token = GenerateJSONWebToken();
                    user.accessToken = token;

                    return user;
                }
                else
                {
                    string  response = "Password and Username Mismatch";
                    return response;
                    
                }
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("login", e.Message);

                throw e;
            }
        }
        #endregion

        #region GetProviderLogin
        public static ExpandoObject providerlogin([FromBody]ProviderLogin providerLogin)
        {
            List<dynamic> userdetails = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@loginProviderType", "Google"));
                parameters.Add(new SqlParameter("@loginProviderKey", providerLogin.loginProviderKey));
                parameters.Add(new SqlParameter("@email", providerLogin.email));
                parameters.Add(new SqlParameter("@name", providerLogin.name));


                DataSet ds = DbConnection.save("spProviderLogin", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];
                dynamic user = new System.Dynamic.ExpandoObject();
               
                if (dt.Rows.Count > 0)
                {
                    user.isNewEntry = (bool?)dt1.Rows[0]["isNewEntry"] ?? false;

                    user.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    user.name = dt.Rows[0]["name"].ToString() ?? "";
                    user.phoneNumber = dt.Rows[0]["phoneNumber"].ToString() ?? "";
                    user.email = dt.Rows[0]["email"].ToString() ?? "";
                    user.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    user.gender = dt.Rows[0]["gender"].ToString() ?? "";
                    user.height = dt.Rows[0]["height"].ToString() ?? "";
                    user.weight = dt.Rows[0]["weight"].ToString() ?? "";
                    user.dob = dt.Rows[0]["dob"].ToString() ?? "";
                    user.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    user.bloodGroupId = (dt.Rows[0]["countryId"] == DBNull.Value ? 0 : (int)dt.Rows[0]["countryId"]); 
                    user.countryName = dt.Rows[0]["countryName"].ToString() ?? "";
                    user.code = dt.Rows[0]["code"].ToString() ?? "";
                    user.bloodGroupId = (dt.Rows[0]["bloodGroupId"] == DBNull.Value ? 0 : (int)dt.Rows[0]["bloodGroupId"]); 
                    user.bloodGroupName = dt.Rows[0]["bloodGroupName"].ToString() ?? "";
                    var token = GenerateJSONWebToken();
                    user.accessToken = token;


                    return user;
                }
                else
                {
                    user.message = "Password and Username Mismatch";
                    return user;
                }
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ProviderLogin", e.Message);

                throw e;
            }
        }
        #endregion
        
    }
}


