﻿using HealthCare.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Model;

namespace HealthCare.BL
{
    public class PaymentBL
    {

        public static dynamic getPlans()
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>(); 
                DataSet ds = DbConnection.save("spGetPlans", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                { 
                    return new { status = "Success", data = ds.Tables[0] }; 
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" }; 
                     
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        } 
        public static dynamic getPaymentHistory(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add( new SqlParameter("@userId", userId));
                DataSet ds = DbConnection.save("spGetPaymentHistory", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

       public static dynamic savePaymentDetails(Payment py)
       {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", py.userId));
                parameters.Add(new SqlParameter("@planId", py.planId));
                parameters.Add(new SqlParameter("@amount", py.amount));
                DataSet ds = DbConnection.save("spSavePaymentDetails", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", message = "Record saved successfully", };
                }
                else
                {
                    return new { status = "Success", message = "Error in payment process", };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getCurrentUserPlan(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataSet ds = DbConnection.save("spGetCurrentPlan", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }



    }
}
