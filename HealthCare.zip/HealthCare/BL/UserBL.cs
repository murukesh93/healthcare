﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Data;
using HealthCare.Model;
using System.Text.RegularExpressions;
using static Nexmo.Api.SMS;
using Microsoft.AspNetCore.Http;

namespace HealthCare.BL
{
    public class UserBL
    {   
        public static dynamic createUser(User user)
        {
            try
            {
                Regex regexEmail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                System.Text.RegularExpressions.Match Email = regexEmail.Match(user.email); 

                if (Email.Success )
                {
                    string timeZone = null;
                    if (!string.IsNullOrEmpty(user.timeZone))
                    {
                        timeZone = OlsonTimeZoneToTimeZoneInfo(user.timeZone);
                    }
                   

                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@name", user.name)); 
                    parameters.Add(new SqlParameter("@email", user.email));
                    parameters.Add(new SqlParameter("@password", user.password));
                    parameters.Add(new SqlParameter("@timeZone", timeZone));
                    parameters.Add(new SqlParameter("@action", "add")); 

                    DataTable dt = DbConnection.GetDataById("spSaveUser", parameters);

                    return new { message = dt.Rows[0]["message"].ToString(), userId = (int)dt.Rows[0]["userId"] };
                }
                else
                {
                    string result = "Please enter valid Email";
                    return new { message = result };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateUser([FromBody]UpdateUser user)
            {
            try
            {

                     string timeZone = null;
                     if (!string.IsNullOrEmpty(user.timeZone))
                     {
                         timeZone = OlsonTimeZoneToTimeZoneInfo(user.timeZone);
                     }

                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@userId", user.userId));
                    parameters.Add(new SqlParameter("@name", user.name)); 
                    parameters.Add(new SqlParameter("@dob", user.dob));
                    parameters.Add(new SqlParameter("@gender", user.gender));
                    parameters.Add(new SqlParameter("@bloodGroup", user.bloodGroup));
                    parameters.Add(new SqlParameter("@profileImage", user.profileImage));
                    parameters.Add(new SqlParameter("@height", user.height));
                    parameters.Add(new SqlParameter("@weight", user.weight)); 
                    parameters.Add(new SqlParameter("@country", user.country)); 
                    parameters.Add(new SqlParameter("@phoneNumber", user.phoneNumber));
                    parameters.Add(new SqlParameter("@Answer", user.securityAnswer));
                    parameters.Add(new SqlParameter("@heightUnit", user.heightUnit));
                    parameters.Add(new SqlParameter("@weightUnit", user.weightUnit));
                    parameters.Add(new SqlParameter("@timeZone", timeZone));
                    parameters.Add(new SqlParameter("@action", "edit"));

                DataTable dt = DbConnection.GetDataById("spSaveUser", parameters);

                dynamic users = new System.Dynamic.ExpandoObject();

                if (dt.Rows.Count > 0)
                {
                    users.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    users.name = dt.Rows[0]["name"].ToString() ?? "";
                    users.phoneNumber = dt.Rows[0]["phoneNumber"].ToString() ?? "";
                    users.email = dt.Rows[0]["email"].ToString() ?? "";
                    users.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    users.gender = dt.Rows[0]["gender"].ToString() ?? "";
                    users.height = dt.Rows[0]["height"].ToString() ?? "";
                    users.weight = dt.Rows[0]["weight"].ToString() ?? "";
                    users.dob = dt.Rows[0]["dob"].ToString() ?? "";
                    users.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    users.countryId = (int?)dt.Rows[0]["countryId"] ?? 0;
                    users.countryName = dt.Rows[0]["countryName"].ToString() ?? "";
                    users.code = dt.Rows[0]["code"].ToString() ?? "";
                    users.bloodGroupId = (int?)dt.Rows[0]["bloodGroupId"] ?? 0;
                    users.bloodGroupName = dt.Rows[0]["bloodGroupName"].ToString() ?? "";
                    var token = LoginBL.GenerateJSONWebToken();
                    users.accessToken = token;

                    return users;
                }
                return users;
                //return new { message = dt.Rows[0]["message"].ToString(), userId = (int)dt.Rows[0]["userId"] };

            }
            catch (Exception e)
            {
                throw e;
            }
        } 
         
        public static dynamic selectUserById(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectUserById", parameters);

                dynamic user = new System.Dynamic.ExpandoObject();
               
                if (dt.Rows.Count > 0)
                {
                    user.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    user.name = dt.Rows[0]["name"].ToString() ?? "";
                    user.phoneNumber = dt.Rows[0]["phoneNumber"].ToString() ?? "";
                    user.email = dt.Rows[0]["email"].ToString() ?? "";
                    user.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    user.gender = dt.Rows[0]["gender"].ToString() ?? "";
                    user.height = dt.Rows[0]["height"].ToString() ?? "";
                    user.weight = dt.Rows[0]["weight"].ToString() ?? "";
                    user.dob = dt.Rows[0]["dob"].ToString() ?? "";
                    user.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    user.bloodGroupId = (dt.Rows[0]["countryId"] == DBNull.Value ? 0 : (int)dt.Rows[0]["countryId"]);
                    user.countryName = dt.Rows[0]["countryName"].ToString() ?? "";
                    user.code = dt.Rows[0]["code"].ToString() ?? "";
                    user.bloodGroupId = (dt.Rows[0]["bloodGroupId"] == DBNull.Value ? 0 : (int)dt.Rows[0]["bloodGroupId"]);
                    user.bloodGroupName = dt.Rows[0]["bloodGroupName"].ToString() ?? "";
                    user.weightUnit = dt.Rows[0]["weightUnit"].ToString() ?? "";
                    user.heightUnit = dt.Rows[0]["heightUnit"].ToString() ?? "";

                }
                return user;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic ForgetPassword([FromBody]ForgetPassword forgetPassword)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", forgetPassword.userId));
                parameters.Add(new SqlParameter("@password", forgetPassword.password));

                DataTable dt = DbConnection.GetDataById("spForgetPassword", parameters);
                return dt.Rows[0][0].ToString();

            }
            catch (Exception e)
            {
                throw e;
            }
        } 

        public static dynamic listCountry()
        {

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>(); 

                DataSet ds = DbConnection.save("spListCountry", parameters);
          
                return new { country = ds.Tables[0], bloodGroup = ds.Tables[1], questionList = ds.Tables[2] };
            }

            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic getSecurityQuestion()
        {
            try
            { 

                List<SqlParameter> parameters = new List<SqlParameter>(); 
                DataSet ds = HealthCare.Data.DbConnection.save("spGetSecurityQuestion", parameters);
             
                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic SaveSecurityQuestionAnswer(SecurityQuestion sec)
        {
            try
            {
 
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@userId", sec.userId));
                    parameters.Add(new SqlParameter("@answer", sec.answer)); 
                    DataTable dt = DbConnection.GetDataById("spSaveSecurityQuestionAnswer", parameters); 

                    return new { message = dt.Rows[0]["ErrorMessage"].ToString() } ; 
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic CheckValidateSecurityQuestion(SecurityQuestion sec)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", sec.userId));
                parameters.Add(new SqlParameter("@answer", sec.answer));
                DataTable dt = DbConnection.GetDataById("spCheckValidateSecurityQuestion", parameters);

                return new { message = dt.Rows[0]["ErrorMessage"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getAnsweredQuestions(string email)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("email", email));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetAnsweredQuestions", parameters);
                DataTable dtQuestionsList = ds.Tables[0];
                if(dtQuestionsList.Rows.Count == 0)
                {
                    return "No security questions found this user";
                }
                else if(dtQuestionsList.Rows[0]["ErrorMessage"].ToString() == "Invalid User")
                {
                    return "Invalid User";
                }
                else
                {
                    return dtQuestionsList;
                }
               
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic SaveDeviceId(userDevice userDevice)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userDevice.userId));
                parameters.Add(new SqlParameter("@firebaseRegID", userDevice.deviceId));

                DataTable dt = DbConnection.GetDataById("spSaveUserDevices", parameters);

                return dt.Rows[0][0].ToString();

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static string OlsonTimeZoneToTimeZoneInfo(string olsonTimeZoneId)
        {


            var olsonWindowsTimes = new Dictionary<string, string>()
        {
        { "Africa/Bangui", "W. Central Africa Standard Time" },
        { "Africa/Cairo", "Egypt Standard Time" },
        { "Africa/Casablanca", "Morocco Standard Time" },
        { "Africa/Harare", "South Africa Standard Time" },
        { "Africa/Johannesburg", "South Africa Standard Time" },
        { "Africa/Lagos", "W. Central Africa Standard Time" },
        { "Africa/Monrovia", "Greenwich Standard Time" },
        { "Africa/Nairobi", "E. Africa Standard Time" },
        { "Africa/Windhoek", "Namibia Standard Time" },
        { "America/Anchorage", "Alaskan Standard Time" },
        { "America/Argentina/San_Juan", "Argentina Standard Time" },
        { "America/Asuncion", "Paraguay Standard Time" },
        { "America/Bahia", "Bahia Standard Time" },
        { "America/Bogota", "SA Pacific Standard Time" },
        { "America/Buenos_Aires", "Argentina Standard Time" },
        { "America/Caracas", "Venezuela Standard Time" },
        { "America/Cayenne", "SA Eastern Standard Time" },
        { "America/Chicago", "Central Standard Time" },
        { "America/Chihuahua", "Mountain Standard Time (Mexico)" },
        { "America/Cuiaba", "Central Brazilian Standard Time" },
        { "America/Denver", "Mountain Standard Time" },
        { "America/Fortaleza", "SA Eastern Standard Time" },
        { "America/Godthab", "Greenland Standard Time" },
        { "America/Guatemala", "Central America Standard Time" },
        { "America/Halifax", "Atlantic Standard Time" },
        { "America/Indianapolis", "US Eastern Standard Time" },
        { "America/Indiana/Indianapolis", "US Eastern Standard Time" },
        { "America/La_Paz", "SA Western Standard Time" },
        { "America/Los_Angeles", "Pacific Standard Time" },
        { "America/Mexico_City", "Mexico Standard Time" },
        { "America/Montevideo", "Montevideo Standard Time" },
        { "America/New_York", "Eastern Standard Time" },
        { "America/Noronha", "UTC-02" },
        { "America/Phoenix", "US Mountain Standard Time" },
        { "America/Regina", "Canada Central Standard Time" },
        { "America/Santa_Isabel", "Pacific Standard Time (Mexico)" },
        { "America/Santiago", "Pacific SA Standard Time" },
        { "America/Sao_Paulo", "E. South America Standard Time" },
        { "America/St_Johns", "Newfoundland Standard Time" },
        { "America/Tijuana", "Pacific Standard Time" },
        { "Antarctica/McMurdo", "New Zealand Standard Time" },
        { "Atlantic/South_Georgia", "UTC-02" },
        { "Asia/Almaty", "Central Asia Standard Time" },
        { "Asia/Amman", "Jordan Standard Time" },
        { "Asia/Baghdad", "Arabic Standard Time" },
        { "Asia/Baku", "Azerbaijan Standard Time" },
        { "Asia/Bangkok", "SE Asia Standard Time" },
        { "Asia/Beirut", "Middle East Standard Time" },
        { "Asia/Calcutta", "India Standard Time" },
        { "Asia/Colombo", "Sri Lanka Standard Time" },
        { "Asia/Damascus", "Syria Standard Time" },
        { "Asia/Dhaka", "Bangladesh Standard Time" },
        { "Asia/Dubai", "Arabian Standard Time" },
        { "Asia/Irkutsk", "North Asia East Standard Time" },
        { "Asia/Jerusalem", "Israel Standard Time" },
        { "Asia/Kabul", "Afghanistan Standard Time" },
        { "Asia/Kamchatka", "Kamchatka Standard Time" },
        { "Asia/Karachi", "Pakistan Standard Time" },
        { "Asia/Katmandu", "Nepal Standard Time" },
        { "Asia/Kolkata", "India Standard Time" },
        { "Asia/Krasnoyarsk", "North Asia Standard Time" },
        { "Asia/Kuala_Lumpur", "Singapore Standard Time" },
        { "Asia/Kuwait", "Arab Standard Time" },
        { "Asia/Magadan", "Magadan Standard Time" },
        { "Asia/Muscat", "Arabian Standard Time" },
        { "Asia/Novosibirsk", "N. Central Asia Standard Time" },
        { "Asia/Oral", "West Asia Standard Time" },
        { "Asia/Rangoon", "Myanmar Standard Time" },
        { "Asia/Riyadh", "Arab Standard Time" },
        { "Asia/Seoul", "Korea Standard Time" },
        { "Asia/Shanghai", "China Standard Time" },
        { "Asia/Singapore", "Singapore Standard Time" },
        { "Asia/Taipei", "Taipei Standard Time" },
        { "Asia/Tashkent", "West Asia Standard Time" },
        { "Asia/Tbilisi", "Georgian Standard Time" },
        { "Asia/Tehran", "Iran Standard Time" },
        { "Asia/Tokyo", "Tokyo Standard Time" },
        { "Asia/Ulaanbaatar", "Ulaanbaatar Standard Time" },
        { "Asia/Vladivostok", "Vladivostok Standard Time" },
        { "Asia/Yakutsk", "Yakutsk Standard Time" },
        { "Asia/Yekaterinburg", "Ekaterinburg Standard Time" },
        { "Asia/Yerevan", "Armenian Standard Time" },
        { "Atlantic/Azores", "Azores Standard Time" },
        { "Atlantic/Cape_Verde", "Cape Verde Standard Time" },
        { "Atlantic/Reykjavik", "Greenwich Standard Time" },
        { "Australia/Adelaide", "Cen. Australia Standard Time" },
        { "Australia/Brisbane", "E. Australia Standard Time" },
        { "Australia/Darwin", "AUS Central Standard Time" },
        { "Australia/Hobart", "Tasmania Standard Time" },
        { "Australia/Perth", "W. Australia Standard Time" },
        { "Australia/Sydney", "AUS Eastern Standard Time" },
        { "Etc/GMT", "UTC" },
        { "Etc/GMT+11", "UTC-11" },
        { "Etc/GMT+12", "Dateline Standard Time" },
        { "Etc/GMT+2", "UTC-02" },
        { "Etc/GMT-12", "UTC+12" },
        { "Europe/Amsterdam", "W. Europe Standard Time" },
        { "Europe/Athens", "GTB Standard Time" },
        { "Europe/Belgrade", "Central Europe Standard Time" },
        { "Europe/Berlin", "W. Europe Standard Time" },
        { "Europe/Brussels", "Romance Standard Time" },
        { "Europe/Budapest", "Central Europe Standard Time" },
        { "Europe/Dublin", "GMT Standard Time" },
        { "Europe/Helsinki", "FLE Standard Time" },
        { "Europe/Istanbul", "GTB Standard Time" },
        { "Europe/Kiev", "FLE Standard Time" },
        { "Europe/London", "GMT Standard Time" },
        { "Europe/Minsk", "E. Europe Standard Time" },
        { "Europe/Moscow", "Russian Standard Time" },
        { "Europe/Paris", "Romance Standard Time" },
        { "Europe/Sarajevo", "Central European Standard Time" },
        { "Europe/Warsaw", "Central European Standard Time" },
        { "Indian/Mauritius", "Mauritius Standard Time" },
        { "Pacific/Apia", "Samoa Standard Time" },
        { "Pacific/Auckland", "New Zealand Standard Time" },
        { "Pacific/Fiji", "Fiji Standard Time" },
        { "Pacific/Guadalcanal", "Central Pacific Standard Time" },
        { "Pacific/Guam", "West Pacific Standard Time" },
        { "Pacific/Honolulu", "Hawaiian Standard Time" },
        { "Pacific/Pago_Pago", "UTC-11" },
        { "Pacific/Port_Moresby", "West Pacific Standard Time" },
        { "Pacific/Tongatapu", "Tonga Standard Time" }
    };

            string value;

            if (olsonWindowsTimes.TryGetValue(olsonTimeZoneId, out value))
            {
                return value;
            }
            else
            {
                return null;
            }
        }

    }
}
