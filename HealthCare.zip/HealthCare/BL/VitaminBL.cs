﻿using HealthCare.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.BL
{
    public class VitaminBL
    {

        public static dynamic SaveVitaminDetails(SaveVitamins obj)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", obj.userId));
                parameters.Add(new SqlParameter("@vitaminDetails", obj.vitaminDetails));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveVitamin", parameters);

                return new { message = "Success" };

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listVitaminDetails(string search, int userId)
        {

            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@search", search ?? ""));
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetGetVitamin", parameters);
                
                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getUserVitaminDetails(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserVitaminDetails", parameters);
               
                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
