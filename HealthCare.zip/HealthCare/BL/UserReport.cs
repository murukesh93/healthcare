﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using HealthCare.Data;
using HealthCare.Model;
using System.Text;
using System.IO;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace HealthCare.BL
{
    public class UserReport
    {
        public static dynamic saveUserReports(SaveUserReports reports)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userId", reports.userId));
                parameters.Add(new SqlParameter("@reportValue", reports.reportValue));
                parameters.Add(new SqlParameter("@unitId", reports.unitId));
                parameters.Add(new SqlParameter("@labtestId", reports.labtestId));
                parameters.Add(new SqlParameter("@reportDate", reports.reportDate));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveUserReportDetails", parameters);


                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic userReport(int userId)
        {
            try
            {
                List<dynamic> reportList = new List<dynamic>();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetPreviousScoreReport", parameters);

                return dt;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic userLabTestReport(int userId)
        {
            try
            {
                List<dynamic> reportList = new List<dynamic>();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spGetLaptestReport", parameters);

                return dt;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic saveUserDashBoardReport(SaveUserDashBoardReports reports)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userId", reports.userId));
                parameters.Add(new SqlParameter("@reportValue", reports.reportValue));
                parameters.Add(new SqlParameter("@unitId", reports.unitId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveUserDashBoardReport", parameters);

                return new { message = "Success" };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic saveUserBloodPressureReport(SaveUserBloodPressure reports)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userId", reports.userId));
                parameters.Add(new SqlParameter("@systolicValue", reports.systolicValue));
                parameters.Add(new SqlParameter("@diastolicValue", reports.diastolicValue));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveUserBloodPressureReport", parameters);

                return new { message = "Success" };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getDashBoardReport()
        {
            try
            {
                List<dynamic> reportList = new List<dynamic>();
                DataTable dt = HealthCare.Data.DbConnection.GetData("spGetDashBoardReport");

                return dt;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getDashBoardReportForGlucose(int userId, string reportType, int? month)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@reportType", reportType));
                parameters.Add(new SqlParameter("@month", month));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserReportForGlucose", parameters);

                DataTable GlucoseReportForUnit1 = ds.Tables[0];
                DataTable GlucoseReportForUnit2 = ds.Tables[1];

                return new {GlucoseReportForUnit1, GlucoseReportForUnit2 };            

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getDashBoardReportForBlood(int userId, string reportType,string type, int? month)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@reportType", reportType));
                parameters.Add(new SqlParameter("@type", type));
                parameters.Add(new SqlParameter("@month", month));
                DataSet ds = null;
                if (type == "Both")
                {
                     ds = HealthCare.Data.DbConnection.save("spGetOverAllUserReportForBlood", parameters);

                    DataTable SystolicReport = ds.Tables[0];
                    DataTable DiastolicReport = ds.Tables[1];

                    return new { SystolicReport, DiastolicReport };
                }
                else
                {
                     ds = HealthCare.Data.DbConnection.save("spGetUserReportForBlood", parameters);

                    List<string> list = new List<string>();

                    if (type == "Diastolic")
                    {
                        DataTable DiastolicReport = ds.Tables[0];
                        return new { SystolicReport = list, DiastolicReport };
                    }
                    else
                    {
                        DataTable SystolicReport = ds.Tables[0];
                        return new { SystolicReport, DiastolicReport = list };
                    }
                }
                

            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic getDashBoardReportValue(int userId, string reportType, string type, string date, string report)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@reportType", reportType));
                parameters.Add(new SqlParameter("@date", date));
                parameters.Add(new SqlParameter("@report", report));
                DataSet ds = null;
                if (type == "Glucose")
                {
                    ds = HealthCare.Data.DbConnection.save("spGetGlucoseReport", parameters);
                }
                else if(type == "BloodPressure")
                {
                    ds = HealthCare.Data.DbConnection.save("spGetBloodPressureReport", parameters);
                }
                return ds.Tables[0];
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getLatestDBeport(int userId, string reportType)
        {
            try
            {
                DataTable dt = null;
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                if (reportType == "Glucose")
                {
                    dt = HealthCare.Data.DbConnection.GetDataById("spGetlatestReportByUserId", parameters);
                }
                else if (reportType == "BloodPressure")
                {
                    dt = HealthCare.Data.DbConnection.GetDataById("spGetlatestBPReportByUserId", parameters);
                }

                return dt;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        

        public static dynamic EditLatestGlucoseReport(Glucose reports)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userReportId", reports.userReportId));
                parameters.Add(new SqlParameter("@reportValue", reports.reportValue));
                parameters.Add(new SqlParameter("@action", "edit"));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteGlucoseReport", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic EditLapTestPreport(LapTestReport lapTestReport)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@reportDetailId", lapTestReport.reportDetailId));
                parameters.Add(new SqlParameter("@reportValue", lapTestReport.reportValue));
                parameters.Add(new SqlParameter("@reportDate", lapTestReport.reportDate));
                parameters.Add(new SqlParameter("@action", "edit"));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteLapTestReport", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic DeleteLapTestPreport(int reportDetailId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@reportDetailId", reportDetailId));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteLapTestReport", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic EditLatestBPreport(BloodPressure reports)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userReportId", reports.userReportId));
                parameters.Add(new SqlParameter("@systolicValue", reports.systolicValue));
                parameters.Add(new SqlParameter("@diastolicValue", reports.diastolicValue));
                parameters.Add(new SqlParameter("@action", "edit"));


                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteBPReport", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic DeleteLatestDBreport(int userReportId, string reportType)
        {
            try
            {
                DataTable dt = null;
                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters.Add(new SqlParameter("@userReportId", userReportId));

                if(reportType =="Glucose")
                {
                     dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteGlucoseReport", parameters);
                }
                else if(reportType == "BloodPressure")
                {
                     dt = HealthCare.Data.DbConnection.GetDataById("spEditAndDeleteBPReport", parameters);
                }

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getGlucoseReportForPDF(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetPdfGlucoseReport", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getBPReportForPDF(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetPdfBPReport", parameters);
                
                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getLabAndRemaindeReport(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetLabAndRemaindeReport", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getUserDetails(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserDetails", parameters);

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static string GetHTMLString(int userId)
        {

            DataTable user = getUserDetails(userId);

            DataSet medicalReport = MedicalConditionBL.getPDFMedicalReport(userId);
            DataTable medicalCondition = medicalReport.Tables[0];
            DataTable familyMedicalCondition = medicalReport.Tables[1];
            DataTable allergies = medicalReport.Tables[2];
            DataTable vitamin = medicalReport.Tables[3];
            DataTable surgeries = medicalReport.Tables[4];


            DataSet drugReport = DrugsBL.getPDFUserMedicinReport(userId);
            DataTable medication = drugReport.Tables[0];
            DataTable interaction = drugReport.Tables[1];

            DataSet glucose = getGlucoseReportForPDF(userId);
            DataTable glucoseWeek = glucose.Tables[0];
            DataTable glucoseMonth = glucose.Tables[1];
            DataTable glucoseYear = glucose.Tables[2];

            DataSet BP = getBPReportForPDF(userId);
            DataTable BPWeek = BP.Tables[0];
            DataTable BPMonth = BP.Tables[1];
            DataTable BPYear = BP.Tables[2];

            DataSet labandReminder =  getLabAndRemaindeReport(userId);
            DataTable laptest = labandReminder.Tables[0];
            DataTable remainder = labandReminder.Tables[1];
            int Count = 0;

            var sb = new StringBuilder();
            int No = 1;
            int i = 0;
            sb.Append(@"<html><head> <style>
@import url('https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&display=swap');
.header {
    text-align: left;
    color: #6C9435;
    font-family: 'Rubik', sans-serif;
}

.pageheadr {
    display: flex;
    align-items: center;
    background: #8EC63F;
    color: #fff;
    font-size: 17px;
    font-family: 'Rubik', sans-serif;
    padding:20px;
}

.wrapper {
    padding: 0;
}

table {
    width: max-content;
    border-collapse: collapse;
    margin-bottom: 2.5rem;
    font-family: 'Rubik', sans-serif;
}

td,
th {
    border: 1px solid gray;
    padding: 15px;
    font-size: 15px;
    text-align: left;
}

table th {
    background-color: green;
    text-align: left;
}

.thead {
    background: #6C9435;
    color: rgb(255, 255, 255);
}
</style></head><body><div class='pageheadr'><h1 style='font-weight:500;align:left;'>Health Care Report <br> تقرير الرعاية الصحية</h1><img src='https://healthcarecontent.s3-us-west-2.amazonaws.com/logo_10-09-2020-10-10-36.png' style='width:140px;height:140px;margin-top:-8.5rem;float:right'/></div><div class='wrapper'>");

            sb.Append(@"<div class='header'><h2>Name: "+ user.Rows[0]["name"]  + "<br> الاسم<br>Email: " + user.Rows[0]["email"]+ "<br> عنوان البريد الإلكتروني" + " </h2></div>");

            // Create medicalCondition report

            if (medicalCondition.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Conditions and Date of Diagnosis<br> شروط وتاريخ التشخيص</h3></div><table><tr><th>No</th><th>Condition <br> التشخيص</th><th>Date of Diagnosis <br> تاريخ التشخيص</th> </tr>");

                for (i = 0; i < medicalCondition.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td></tr>", No, medicalCondition.Rows[i]["engName"] + "<br> " + medicalCondition.Rows[i]["arbName"], medicalCondition.Rows[i]["commentDate"]);
                    No = No + 1;
                    Count = Count + 1;
                }
                sb.Append(@"</table>");

                No = 1;
            }

            // Create familyMedicalCondition report

            if (familyMedicalCondition.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Family Medical History<br> التاريخ الطبي للعائلة </h3></div><table><tr><th>No</th><th>Condition <br> التشخيص</th><th>Date of Diagnosis <br> تاريخ التشخيص</th><th>Member Name <br> اسم فرد العائلة</th><th>Relationship <br> علاقة فرد العائلة بك</th> </tr>");

                for (i = 0; i < familyMedicalCondition.Rows.Count; i++)
                {

                    string result = familyMedicalCondition.Rows[i]["familyConditionalDetails"].ToString();

                    JArray data = JArray.Parse(@result);

                    for (var k = 0; k < data.Count(); k++)
                    {
                        string data1 = data[k].ToString();
                        dynamic report = JObject.Parse(data1);

                        sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>", No, report.engName + "<br> " + report.arbName, report.commentDate, familyMedicalCondition.Rows[i]["memberName"], familyMedicalCondition.Rows[i]["relationship"]);
                        No = No + 1;
                        Count = Count + 1;


                    }
                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create allergies report
            if (allergies.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Allergies<br>الحساسية</h3></div><table><tr><th>No</th><th>Allergies <br> الحساسية</th><th>Date of Diagnosis <br> تاريخ التشخيص</th> </tr>");

                for (i = 0; i < allergies.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td></tr>", No, allergies.Rows[i]["engname"] + "<br> " + allergies.Rows[i]["arbName"], allergies.Rows[i]["commentDate"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create vitamin report
            if (vitamin.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Vitamins & Supplements<br>الفيتامينات والمكملات الغذائية</h3></div><table>  <tr><th>No</th><th>Vitamin and Supplement <br> الفيتامينات والمكملات الغذائية</th> <th>Date You Started Taking Them <br> تاريخ بدء الاستخدام</th> </ tr >");

                for (i = 0; i < vitamin.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr><td>{0}</td><td>{1}</td><td>{2}</td> </tr>", No, vitamin.Rows[i]["engname"] + "<br> " + vitamin.Rows[i]["arbName"], vitamin.Rows[i]["commentDate"]);

                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");
                No = 1;
            }
            // Create Surgeries and Therapies report
            if (surgeries.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Surgeries & Therapies<br>الجراحات والعلاجات</h3></div><table>  <tr><th>No</th><th>Surgeries & Therapies <br> الجراحات والعلاجات</th> <th>Date of Diagnosis <br> التاريخ</th> </tr>");

                for (i = 0; i < surgeries.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr><td>{0}</td><td>{1}</td><td>{2}</td> </tr>", No, surgeries.Rows[i]["engTherapies"] + "<br>" + surgeries.Rows[i]["arbTherapies"], surgeries.Rows[i]["commentDate"]);

                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");
                No = 1;
            }

            //// Create Medication report
            //if (medication.Rows.Count > 0)
            //{
            //    sb.Append(@"<div class='header'><h3>Medications<br>الأدوية</h3></div><table>  <tr><th>No</th><th>Medical Uses Of The Drug <br> الاستخدامات الطبية للدواء</th><th>Trade Name <br> الاسم التجاري</th><th>Generic Name <br> الاسم العام</th><th>Strength Value <br> قوة الدواء</th> <th>Volume <br>  حجم الدواء</th> </tr>");

            //    for (i = 0; i < medication.Rows.Count; i++)
            //    {
            //        sb.AppendFormat(@"<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td></tr>",
            //            No, medication.Rows[i]["engUse"] + "<br>" + medication.Rows[i]["arbUse"], medication.Rows[i]["medicineName"] + "<br> " + medication.Rows[i]["arbMedicineName"], medication.Rows[i]["genericName"] + "<br> " + medication.Rows[i]["ArbgenericName"], medication.Rows[i]["strengthValue"], medication.Rows[i]["volume"] );

            //        No = No + 1;
            //    }
            //    sb.Append(@"</table>");
            //    No = 1;
            //    Count = Count + 1;

            //}

            // Create Medication report
            if (medication.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Medications<br>الأدوية</h3></div><table>  <tr><th>No</th><th>Trade Name <br> الاسم التجاري</th><th>Generic Name <br> الاسم العام</th><th>Strength Value <br> قوة الدواء</th> <th>Volume <br>  حجم الدواء</th> <th> Shelf Life (months) <br>  مدّة الصلاحية بالأشهر</th> <th>Package Size <br>  حجم العبوة</th><th> Storage Conditions (°C)  <br> درجة حرارة التخزين بالدرجات المئوية</th><th>Manufacturer Name <br>  اسم المصنع</th><th>Country of Manufacturer <br>  بلد الشركة المصنعة</th><th>Price In Saudi Riyal <br> السعر بالريال السعودي</th> </tr>");

                for (i = 0; i < medication.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td></tr>",
                        No, medication.Rows[i]["medicineName"] + "<br> " + medication.Rows[i]["arbMedicineName"], medication.Rows[i]["genericName"] + "<br> " + medication.Rows[i]["ArbgenericName"], medication.Rows[i]["strengthValue"], medication.Rows[i]["volume"], medication.Rows[i]["life"], medication.Rows[i]["packageSize"], medication.Rows[i]["storageCondition"], medication.Rows[i]["manufactureName"], medication.Rows[i]["country"] + "<br> " + medication.Rows[i]["arbcountry"], medication.Rows[i]["price"]);

                    No = No + 1;
                }
                sb.Append(@"</table>");
                No = 1;
                Count = Count + 1;

            }
            // Create Serious Medication Interaction report
            if (interaction.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Serious Medication Interactions Based on the Drug’s Generic Name<br>التفاعلات الدوائية الخطيرة بناءً على الاسم العام للدواء</h3></div><table align ='center'>  <tr><th>No</th><th>First Medication <br> الدواء رقم واحد</th> <th>Second Medication <br> الدواء رقم اثنين</th> <th>Interaction <br> التفاعل</th> </ tr >");

                for (i = 0; i < interaction.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>", No, interaction.Rows[i]["fromTradeName"], interaction.Rows[i]["toTradeName"], interaction.Rows[i]["interaction"] + "<br>" + interaction.Rows[i]["arbInteraction"]);

                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");
                No = 1;
            }
            // Create Glucose Level tracker for Week report
            if (glucoseWeek.Rows.Count > 0)
            {

                sb.Append(@"<div class='header'><h3>Glucose Level Report<br>تقرير مستوى الجلوكوز</h3></div><table><tr><th>No</th><th>Glucose Value For unit mmol/l <br> متوسط ​​القيمة</th><th>Glucose Value For unit mg/dl <br> متوسط ​​القيمة</th><th>Report Week التقرير الأسبوعي</th> <th>Report Date <br> التاريخ الذي تم فيه إنشاء التقرير</th></tr>");

                for (i = 0; i < glucoseWeek.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>", No,  glucoseWeek.Rows[i]["unit1ReportValue"], glucoseWeek.Rows[i]["unit2ReportValue"], glucoseWeek.Rows[i]["report"], glucoseWeek.Rows[i]["reportDateTime"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create Glucose Level tracker for Month report
            if (glucoseMonth.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Glucose Level Report<br>تقرير مستوى الجلوكوز</h3></div><table><tr><th>No</th><th>Glucose Value For unit mmol/l <br> متوسط ​​القيمة</th><th>Glucose Value For unit mg/dl <br> متوسط ​​القيمة</th><th>Report Month <br>  التقرير الشهري</th></tr>");

                for (i = 0; i < glucoseMonth.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>", No, glucoseMonth.Rows[i]["unit1ReportValue"], glucoseMonth.Rows[i]["unit2ReportValue"], glucoseMonth.Rows[i]["report"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create Glucose Level tracker for Year report
            if (glucoseYear.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Glucose Level Report<br>تقرير مستوى الجلوكوز</h3></div><table><tr><th>No</th><th>Glucose Value For unit mmol/l <br> متوسط ​​القيمة</th><th>Glucose Value For unit mg/dl <br> متوسط ​​القيمة</th><th>Report Year <br> التقرير السنوي</th></tr>");

                for (i = 0; i < glucoseYear.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>", No, glucoseYear.Rows[i]["unit1ReportValue"], glucoseYear.Rows[i]["unit2ReportValue"], glucoseYear.Rows[i]["report"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create BP Level tracker for Week report
            if (BPWeek.Rows.Count > 0)
            {

                sb.Append(@"<div class='header'><h3>Blood Pressure Report<br>تقرير ضغط الدم</h3></div><table><tr><th>No</th><th>Systolic Value <br> متوسط ​​القيمة</th><th>Diastolic Value <br> متوسط ​​القيمة</th><th>Report Week <br> التقرير الأسبوعي</th><th>Report Date <br> التاريخ الذي تم فيه إنشاء التقرير</th></tr>");

                for (i = 0; i < BPWeek.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>", No, BPWeek.Rows[i]["systolicValue"], BPWeek.Rows[i]["diastolicValue"], BPWeek.Rows[i]["report"], BPWeek.Rows[i]["reportDateTime"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create BP Level tracker for Month report
            if (BPMonth.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Blood Pressure Report<br>تقرير ضغط الدم</h3></div><table><tr><th>No</th><th>Systolic Value <br> متوسط ​​القيمة</th><th>Diastolic Value <br> متوسط ​​القيمة</th><th>Report Month <br>  التقرير الشهري</th></tr>");

                for (i = 0; i < BPMonth.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>", No, BPMonth.Rows[i]["systolicValue"], BPMonth.Rows[i]["diastolicValue"],  BPMonth.Rows[i]["report"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create BP Level tracker for Year report
            if (BPYear.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Blood Pressure Report<br>تقرير ضغط الدم</h3></div><table><tr><th>No</th><th>Systolic Value <br> متوسط ​​القيمة</th><th>Diastolic Value <br> متوسط ​​القيمة</th><th>Report Year <br> التقرير السنوي</th></tr>");

                for (i = 0; i < BPYear.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>", No, BPYear.Rows[i]["systolicValue"], BPYear.Rows[i]["diastolicValue"], BPYear.Rows[i]["report"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create Lap tests  report
            if (laptest.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Lab Tests Report<br>تقرير الاختبارات المعملية</h3></div><table><tr><th>No</th><th>Lab Test Name <br> اسم الاختبار المعملي</th><th>Report Score <br> تقرير النتيجة</th><th>Meaning Of the Result <br>  معنى النتيجة</th><th>Report Date and Time <br> تاريخ ووقت التقرير</th></tr>");

                for (i = 0; i < laptest.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>", No, laptest.Rows[i]["componentName"] + " <br>" + laptest.Rows[i]["arbComponentName"], laptest.Rows[i]["reportValue"], laptest.Rows[i]["result"], laptest.Rows[i]["reportDate"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }
            // Create remainder  report
            if (remainder.Rows.Count > 0)
            {
                sb.Append(@"<div class='header'><h3>Reminders<br>تذكير</h3></div><table><tr><th>No</th><th>Reminder Type <br> نوع التذكير</th><th>Medicine/Vitamin/Supplement Name <br> الدواء / اسم الفيتامين / اسم المكمل الغذائي</th><th>Dosage <br> الجرعة</th><th>Quantity <br> الكمية</th><th>Time <br> الوقت</th><th>Notes <br> ملاحظات</th></tr>");

                for (i = 0; i < remainder.Rows.Count; i++)
                {
                    sb.AppendFormat(@"<tr> <td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td></tr>", No, remainder.Rows[i]["referenceType"], remainder.Rows[i]["medicineName"] + "<br> " + remainder.Rows[i]["arbMedicineName"], remainder.Rows[i]["takenVolume"], remainder.Rows[i]["quantity"], remainder.Rows[i]["reportTime"], remainder.Rows[i]["notes"]);
                    No = No + 1;
                    Count = Count + 1;

                }
                sb.Append(@"</table>");

                No = 1;
            }

            sb.Append(@"</div><script type='text/javascript' src='js/script.js'></script></body></html>");
            if (Count == 0)
            {
                return "Report not available for this user";

            }
            else
            {
                return sb.ToString();

                //return sb.ToString().Replace("\r\n", "");
            }

        }
      
    }
}
