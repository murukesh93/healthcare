﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Data;
using HealthCare.Model;

namespace HealthCare.BL
{
    public class MedicalConditionBL
    {

        public static dynamic saveMedicalCondition(SaveMedicalCondition med)
        {
            try
            {
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@userId", med.userId));
                    parameters.Add(new SqlParameter("@medicalCondition", med.medicalCondition)); 

                    DataTable dt =HealthCare.Data.DbConnection.GetDataById("spSaveMedicalCondition", parameters);

                    return new { message = "Success" };
               

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listMedicalCondition(string search, int userId, int familyMedicalHistoryId)
        {
            
            try
            {
                
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@search", search ?? ""));
                parameters.Add(new SqlParameter("@familyMedicalHistoryId", familyMedicalHistoryId > 0 ? familyMedicalHistoryId : 0 ));

                DataSet ds = HealthCare.Data.DbConnection.save("spGetMedicalConditon", parameters);

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listUserMedicalCondition(int userId)
        {  
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId)); 
                DataSet ds = HealthCare.Data.DbConnection.save("spGetUserMedicalConditon", parameters);
                
                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }



        public static dynamic saveFamilyMedicalCondition(SaveFamilyMedicalCondition med)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", med.userId));
                parameters.Add(new SqlParameter("@medicalCondition", med.medicalCondition));
                parameters.Add(new SqlParameter("@relationship", med.relationship));
                parameters.Add(new SqlParameter("@memberName", med.memberName));
                parameters.Add(new SqlParameter("@familyMedicalHistoryId", med.familyMedicalHistoryId));
                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spSaveFamilyMedicalCondition", parameters);

                return new { message = "Success" };


            }
            catch (Exception e)
            {
                throw e;
            }
        }

      
        public static dynamic listFamilyMedicalCondition(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetFamilyMedicalConditon", parameters);

                return ds.Tables[0];
            }

            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getPDFMedicalReport(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetPDFMedicalReport", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getPDFMedicalReport(int userId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId));
                DataSet ds = HealthCare.Data.DbConnection.save("spGetPDFMedicalReport", parameters);

                return ds;
            }

            catch (Exception e)
            {
                throw e;
            }
        }

    }


}
