﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Data;
using HealthCare.Model;
using System.Text.RegularExpressions;
using static HealthCare.Model.RemainderModel;

namespace HealthCare.BL
{
    public class RemainderBL
    {
        public static dynamic createRemainder(Remainder remainder)
        {
            try
            {
                
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@userId", remainder.userId));
                    parameters.Add(new SqlParameter("@referenceId", remainder.referenceId));
                    parameters.Add(new SqlParameter("@referenceType", remainder.referenceType));
                    parameters.Add(new SqlParameter("@notes", remainder.notes));
                    parameters.Add(new SqlParameter("@refillDate", remainder.refillDate));
                    parameters.Add(new SqlParameter("@fromDate", remainder.fromDate));
                    parameters.Add(new SqlParameter("@toDate", remainder.toDate));
                    parameters.Add(new SqlParameter("@timeZone", remainder.timeZone));
                    parameters.Add(new SqlParameter("@remainderTime", remainder.remainderTime));
                    parameters.Add(new SqlParameter("@isNoEndDate", remainder.isNoEndDate));
                    parameters.Add(new SqlParameter("@isNoEndDateForRefill", remainder.isNoEndDateForRefill));
                    parameters.Add(new SqlParameter("@remindRefillDay", remainder.remindRefillDay));

                DataTable dt = DbConnection.GetDataById("spSaveRemainder", parameters);
                  return dt.Rows[0][0].ToString();


            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateRemainder(UpdateRemainder remainder)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@remainderId", remainder.remainderId));
                parameters.Add(new SqlParameter("@referenceId", remainder.referenceId)); 
                parameters.Add(new SqlParameter("@referenceType", remainder.referenceType));
                parameters.Add(new SqlParameter("@notes", remainder.notes));
                parameters.Add(new SqlParameter("@refillDate", remainder.refillDate));
                parameters.Add(new SqlParameter("@fromDate", remainder.fromDate));
                parameters.Add(new SqlParameter("@toDate", remainder.toDate));
                parameters.Add(new SqlParameter("@timeZone", remainder.timeZone));
                parameters.Add(new SqlParameter("@remainderTime", remainder.remainderTime));
                parameters.Add(new SqlParameter("@isNoEndDate", remainder.isNoEndDate));
                parameters.Add(new SqlParameter("@isNoEndDateForRefill", remainder.isNoEndDateForRefill));
                parameters.Add(new SqlParameter("@remindRefillDay", remainder.remindRefillDay));

                DataTable dt = DbConnection.GetDataById("spUpdateRemainder", parameters);
                return dt.Rows[0][0].ToString();


            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getRemainderListById(int userId)
        {
            try
            {
                List<dynamic> refillInfo = new List<dynamic>();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataSet ds = DbConnection.save("spGetRemainderList", parameters);

                dynamic remainderInfo = new System.Dynamic.ExpandoObject();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    remainderInfo.Morning = ds.Tables[0].Rows[0]["Morning"].ToString() ?? "";
                    remainderInfo.Noon = ds.Tables[0].Rows[0]["Noon"].ToString() ?? "";
                    remainderInfo.Evening = ds.Tables[0].Rows[0]["Evening"].ToString() ?? "";
                    remainderInfo.BedTime = ds.Tables[0].Rows[0]["BedTime"].ToString() ?? "";

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    for (var i = 0; i < ds.Tables[1].Rows.Count; i++)
                    {
                        dynamic refill = new System.Dynamic.ExpandoObject();
                        refill.remainderId = (int?)ds.Tables[1].Rows[i]["remainderId"] ?? 0;
                        refill.refillDate = ds.Tables[1].Rows[i]["refillDate"].ToString() ?? "";
                        refill.medicineName = ds.Tables[1].Rows[i]["medicineName"].ToString() ?? "";
                        refill.notes = ds.Tables[1].Rows[i]["notes"].ToString() ?? "";
                        refillInfo.Add(refill);
                    }

                }

                return new { remainderInfo, refillInfo };

            }
            catch (Exception e)
            {
                throw e;
            }

        }
            public static dynamic getAllRemainderListById(int userId)
            {
                try
                {
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                    DataSet ds = DbConnection.save("spGetAllRemainderList", parameters);

                    return ds.Tables[0];

                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            public static dynamic getTimeZone()
        {
            try
            {
                List<dynamic> timeZoneList = new List<dynamic>();
                DataTable dt = DbConnection.GetData("spGetTimeZone");
               
                if (dt.Rows.Count > 0)
                {
                    for (var i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic timeZone = new System.Dynamic.ExpandoObject();

                        timeZone.timeZone = dt.Rows[i]["name"].ToString() ?? "";
                        timeZone.quantity = dt.Rows[i]["current_utc_offset"].ToString() ?? "";
                        timeZoneList.Add(timeZone);
                    }

                }
                return timeZoneList;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getRemainderById(int remainderId)
        {
            try
            {
                
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@remainderId", remainderId));
                DataTable dt = DbConnection.GetDataById("spGetRemainderByid", parameters);
                dynamic remainder = new System.Dynamic.ExpandoObject();

                if (dt.Rows.Count > 0)
                {
                    remainder.remainderId = (int?)dt.Rows[0]["remainderId"] ?? 0;
                    remainder.referenceId = (int?)dt.Rows[0]["referenceId"] ?? 0;
                    remainder.referenceType = dt.Rows[0]["referenceType"].ToString() ?? "";
                    remainder.notes = dt.Rows[0]["notes"].ToString() ?? "";
                    remainder.timeZone = dt.Rows[0]["timeZone"].ToString() ?? "";
                    remainder.refillDate = dt.Rows[0]["refillDate"].ToString() ?? "";
                    remainder.fromdate = dt.Rows[0]["fromdate"].ToString() ?? "";
                    remainder.toDate = dt.Rows[0]["toDate"].ToString() ?? "";
                    remainder.time = dt.Rows[0]["time"].ToString() ?? "";
                    remainder.quantity = dt.Rows[0]["quantity"].ToString() ?? "";
                    remainder.takenVolume = dt.Rows[0]["takenVolume"].ToString() ?? "";

                    //remainder.reminderTime = dt.Rows[0]["remainderTime"].ToString() ?? "";
                    remainder.isNoEndDate = (bool?)dt.Rows[0]["isNoEndDate"] ?? false;
                    remainder.isNoEndDateForRefill = (bool?)dt.Rows[0]["isNoEndDateForRefill"] ?? false;
                    remainder.remindRefillDay = (int?)dt.Rows[0]["remindRefillDay"] ?? 0;

                }

                return remainder;

            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public static dynamic DeleteRemainder( int remainderId)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@remainderId", remainderId));

                DataTable dt = HealthCare.Data.DbConnection.GetDataById("spDeleteRemainder", parameters);

                return new { message = dt.Rows[0]["message"].ToString() };
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
