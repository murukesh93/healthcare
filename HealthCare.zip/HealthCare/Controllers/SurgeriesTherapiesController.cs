﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class SurgeriesTherapiesController : ControllerBase
    {

        #region listSurgeriesTherapies
        /// <summary>
        /// To list all the Surgeries and Therapies
        /// </summary>
        [HttpGet, Route("listSurgeriesTherapies")]
        public IActionResult listSurgeriesTherapies(string search, int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok( SurgeriesTherapiesBL.listSurgeriesTherapies(search, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listSurgeriesTherapies", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region saveSurgeriesTherapies
        /// <summary>
        /// To save user selected Surgeries and Therapies
        /// </summary>
        [HttpPost, Route("saveSurgeriesTherapies")]
        [AllowAnonymous]
        public IActionResult saveMedicalCondition(SaveTherapies theobj )
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = SurgeriesTherapiesBL.saveSurgeriesTherapies(theobj);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveSurgeriesTherapies", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region listUserSurgeriesTherapies
        /// <summary>
        /// To select user entered Surgeries Therapies
        /// </summary>
        [HttpGet, Route("listUserSurgeriesTherapies")]
        public IActionResult listUserSurgeriesTherapies([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(SurgeriesTherapiesBL.listUserSurgeriesTherapies(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listUserSurgeriesTherapies", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

    }
}