﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DrugsController : ControllerBase
    {


        #region listMedicineDetails
        /// <summary>
        /// To get all the drug list
        /// </summary>
        [HttpGet, Route("listDrugs")]
        public IActionResult listDrugs([Required] int userId, string search, [Required] int count, [Required] int offset)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(DrugsBL.listMedicineDetails(userId,search,count,offset));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listDrugs", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getDrugInteractionById
        /// <summary>
        /// To get drug Interaction By UserId
        /// </summary>
        [HttpGet, Route("getDrugInteractionById")]
        public IActionResult getDrugInteractionById([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(DrugsBL.getDrugInteractionById(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDrugInteractionById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region SaveMedicineDetails
        /// <summary>
        /// To save user selected Medicine Details
        /// </summary>
        [HttpPost, Route("SaveMedicineDetails")]
        [AllowAnonymous]
        public IActionResult SaveMedicineDetails(SaveMedicine theobj)
        {
            try
            {  

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = DrugsBL.SaveMedicineDetails(theobj);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = "Failed to save." });
                   // return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("SaveMedicineDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region listUserMedicineDetails
        /// <summary>
        /// To select user entered medicine details
        /// </summary>
        [HttpGet, Route("listUserMedicineDetails")]
        public IActionResult listUserMedicineDetails([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(DrugsBL.listUserMedicineDetails(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listUserMedicineDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getAttributes
        /// <summary>
        /// To getAttributes
        /// </summary>
        [HttpGet, Route("getAttributes")]
        public IActionResult getAttributes()
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(DrugsBL.getAttributes());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getAttributes", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
        #region getDiseaseResult
        /// <summary>
        /// To getDiseaseResult
        /// </summary>
        [HttpGet, Route("getDiseaseResult")]
        [AllowAnonymous]
        public IActionResult getDiseaseResult(string possiblevalues)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(DrugsBL.getDiseaseResult(possiblevalues));


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDiseaseResult", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
    }
}