﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PushNotificationController : ControllerBase
    {
        [HttpPost, Route("sendNotification")]
        public IActionResult sendNotification(PushNotification pushNotification)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = PushNotificationsBL.pushNotification(pushNotification);

            if(Convert.ToString(result)== "Notification Send Successfully")
            {
                return StatusCode((int)HttpStatusCode.OK, new { message = result });
            }
            else
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result });
            }
        }
        #region ReadNotification
        /// <summary>
        /// To read notification
        /// </summary>
        [HttpGet, Route("ReadNotification")]
        public IActionResult ReadNotification([Required]int notificationId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }


                var result = PushNotificationsBL.ReadNotification(notificationId);
                if (Convert.ToString(result) == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Notification updated successfully." });

                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result.message });
                }


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ReadNotification", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getNotification
        /// <summary>
        /// List all the Answered Questions
        /// </summary>
        [HttpGet, Route("getNotificationById")]
        public IActionResult getNotificationById([Required]int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(PushNotificationsBL.getNotification(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getNotificationById", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region UserNotificationCount
        [HttpGet, Route("UserNotificationCount")]
        public IActionResult UserNotificationCount([Required]int userId)
        {
            try
            {

                return Ok(PushNotificationsBL.UserNotificationCount(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("UserNotificationCount", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region ConfirmRemainder
        /// <summary>
        /// To Confirm remainder
        /// </summary>
        [HttpGet, Route("ConfirmRemainder")]
        public IActionResult ConfirmRemainder([Required]int notificationId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = PushNotificationsBL.ConfirmRemainder(notificationId);
                if (Convert.ToString(result) == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Reminder confirmed successfully." });

                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result.message });
                }


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ConfirmRemainder", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
    }
}