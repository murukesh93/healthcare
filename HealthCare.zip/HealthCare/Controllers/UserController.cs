﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.BL;
using HealthCare.Data;
using HealthCare.Model;
using Newtonsoft.Json;

namespace HealthCare.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    
    public class UserController : ControllerBase
    {
        #region createUser
        /// <summary>
        /// To create new User
        /// </summary>
        [HttpPost, Route("user")]
        [AllowAnonymous]
        public IActionResult createUser(User user)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserBL.createUser(user);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else if (result.Contains("UQ__tblUser__AB6E616497B9A498"))   // Check Duplicate Key for Email
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = "Email ID already exists \n عنوان البريد الإلكتروني هذا مأخوذ" });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createUser", e.Message);

                if (e.Message.Contains("UQ__tblUser__AB6E616474BB8662"))   // Check Duplicate Key for Email
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = "Email ID already exists \n عنوان البريد الإلكتروني هذا مأخوذ" });
                }
                else
                    {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
                }
            }
        }
        #endregion 

        #region updateUser
        /// <summary>
        /// To update particular User
        /// </summary>
        [HttpPut, Route("user")]
        public IActionResult updateUser(UpdateUser updateUser)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
              
                return Ok(UserBL.updateUser(updateUser));
               
                //return null;
            }
            catch (Exception e)
            {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
                 
            }
        }
        #endregion  

        #region selectUserById
        /// <summary>
        /// To  select UserById
        /// </summary>
        [HttpGet, Route("user")]
        public IActionResult selectUserById([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok( UserBL.selectUserById(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectUserById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion 


        #region forgetPassword
        /// <summary>
        /// To update forgetPassword
        /// </summary>
        [HttpPut, Route("forgetPassword")]
        [AllowAnonymous]
        public IActionResult forgetPassword(ForgetPassword forgotPassword)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result =  UserBL.ForgetPassword(forgotPassword);
                if (result == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Password Updated Successfully" });
                }
                else
                {
                    //return "Invalid user";
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result.message });
                }
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("forgetPassword", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion forgetPassword    


        #region listCountry
        /// <summary>
        /// List all country and blood group list
        /// </summary>
        [HttpGet, Route("listCountry")]
        public IActionResult listCountry()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                return Ok( UserBL.listCountry());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listCountry", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region getSecurityQuestion
        /// <summary>
        /// List all the security Questions
        /// </summary>
        [HttpGet, Route("getSecurityQuestion")]
        [AllowAnonymous]
        public IActionResult getSecurityQuestion()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(UserBL.getSecurityQuestion());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getSecurityQuestion", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region SaveSecurityQuestionAnswer
        /// <summary>
        /// To save user security question answer  
        /// </summary>
        [HttpPost, Route("SaveSecurityQuestionAnswer")]
        [AllowAnonymous]
        public IActionResult SaveSecurityQuestionAnswer(SecurityQuestion sec)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserBL.SaveSecurityQuestionAnswer(sec);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("SaveSecurityQuestionAnswer", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region CheckValidateSecurityQuestion
        /// <summary>
        /// To validate security question answer 
        /// </summary>
        [HttpPost, Route("CheckValidateSecurityQuestion")]
        [AllowAnonymous]
        public IActionResult CheckValidateSecurityQuestion(SecurityQuestion sec)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserBL.CheckValidateSecurityQuestion(sec);

                if (result.message == "Valid User")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("CheckValidateSecurityQuestion", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getAnsweredQuestions
        /// <summary>
        /// List all the Answered Questions
        /// </summary>
        [HttpGet, Route("getAnsweredQuestions")]
        public IActionResult getAnsweredQuestions(string email)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = UserBL.getAnsweredQuestions(email);

                    if (data is string)
                    {
                        return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = data });
                    }
                    else
                    {
                        return Ok(data);
                    } 
                

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getAnsweredQuestions", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion




        #region SaveDeviceId
        /// <summary>
        /// To Save DeviceId for User
        /// </summary>
        [HttpPost, Route("SaveDeviceId")]
        [AllowAnonymous]
        public IActionResult SaveDeviceId(userDevice userDevice)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserBL.SaveDeviceId(userDevice);

                if (result == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Device Saved Successfully" });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("SaveDeviceId", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion
    }
}