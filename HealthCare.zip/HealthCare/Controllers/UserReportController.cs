﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.BL;
using System.Net;
using System.IO;
using System.Text;
using Aspose.Pdf.Facades;
using DinkToPdf;
using DinkToPdf.Contracts;
using PDF_Generator.Utility;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class UserReportController : ControllerBase
    {

        private IConverter _converter;
        public UserReportController(IConverter converter)
        {
            _converter = converter;
        }

        #region  saveUserReports
        /// <summary>
        /// To save user Reports
        /// </summary>
        [HttpPost, Route("saveUserReports")]
        [AllowAnonymous]
        public IActionResult saveUserReports(SaveUserReports reports)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.saveUserReports(reports);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveUserReports", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion

        #region userReport
        /// <summary>
        /// To  userReport
        /// </summary>
        [HttpGet, Route("userReport")]
        public IActionResult userReport([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(UserReport.userReport(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("userReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region userLabTestReport
        /// <summary>
        /// To  userLabTestReport
        /// </summary>
        [HttpGet, Route("userLabTestReport")]
        public IActionResult userLabTestReport([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.userLabTestReport(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("userLabTestReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region  saveUserDashBoardReport
        /// <summary>
        /// To save user DashBoardReport
        /// </summary>
        [HttpPost, Route("saveUserDashBoardReport")]
        public IActionResult saveUserDashBoardReport(SaveUserDashBoardReports reports)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.saveUserDashBoardReport(reports);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveUserDashBoardReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion

        #region  saveUserBloodPressureReport
        /// <summary>
        /// To save user BloodPressureReport
        /// </summary>
        [HttpPost, Route("saveUserBloodPressureReport")]
        public IActionResult saveUserBloodPressureReport(SaveUserBloodPressure reports)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.saveUserBloodPressureReport(reports);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveUserBloodPressureReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion

        #region getDashBoardReport
        /// <summary>
        /// To  get DashBoardReport
        /// </summary>
        [HttpGet, Route("getDashBoardReport")]
        public IActionResult getDashBoardReport()
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.getDashBoardReport());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDashBoardReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region getDashBoardReportForGlucose
        /// <summary>
        /// To  get DashBoardReport by userId for glucose
        /// </summary>
        [HttpGet, Route("getDashBoardReportForGlucose")]
        public IActionResult getDashBoardReportForGlucose([Required]int userId, string reportType, int? month)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.getDashBoardReportForGlucose(userId, reportType, month));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDashBoardReportForGlucose", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getDashBoardReportForBlood
        /// <summary>
        /// To  get DashBoardReport by userId for blood pressure
        /// </summary>
        [HttpGet, Route("getDashBoardReportForBlood")]
        public IActionResult getDashBoardReportForBlood([Required]int userId, [Required]string reportType, [Required]string type, int? month)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.getDashBoardReportForBlood(userId, reportType, type, month));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDashBoardReportForBlood", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getDashBoardReportValue
        /// <summary>
        /// To  get getDashBoardReportValue 
        /// </summary>
        [HttpGet, Route("getDashBoardReportValue")]
        public IActionResult getDashBoardReportValue([Required]int userId, [Required]string reportType, [Required]string type, [Required]string date, string report)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.getDashBoardReportValue(userId, reportType, type, date, report));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getDashBoardReportValue", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region getLatestDBeport
        /// <summary>
        /// To  getLatestDBeport
        /// </summary>
        [HttpGet, Route("getLatestDBeport")]
        public IActionResult getLatestDBeport([Required]int userId, [Required]string reportType)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserReport.getLatestDBeport(userId, reportType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getLatestDBeport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region  EditLatestGlucoseReport
        /// <summary>
        /// To edit latest Glucose Report
        /// </summary>
        [HttpPut, Route("EditLatestGlucoseReport")]
        public IActionResult EditLatestGlucoseReport(Glucose reports)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.EditLatestGlucoseReport(reports);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("EditLatestGlucoseReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region  EditLatestBPreport
        /// <summary>
        /// To Edit latest BloodPressure Report
        /// </summary>
        [HttpPut, Route("EditLatestBPreport")]
        public IActionResult EditLatestBPreport(BloodPressure reports)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.EditLatestBPreport(reports);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("EditLatestBPreport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region  DeleteLatestDBreport
        /// <summary>
        /// To  DeleteLatestDBreport
        /// </summary>
        [HttpDelete, Route("DeleteLatestDBreport")]
        public IActionResult DeleteLatestDBreport([Required]int userReportId, [Required]string reportType)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.DeleteLatestDBreport(userReportId, reportType);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("DeleteLatestDBreport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion

        #region  EditLabTestReport
        /// <summary>
        /// To Edit LabTest Report
        /// </summary>
        [HttpPut, Route("EditLabTestReport")]
        public IActionResult EditLabTestReport(LapTestReport lapTestReport)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = UserReport.EditLapTestPreport(lapTestReport);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("EditLabTestReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region  DeleteLabTestReport
        /// <summary>
        /// To  DeleteLabTestReport
        /// </summary>
        [HttpDelete, Route("DeleteLabTestReport")]
        public IActionResult DeleteLabTestReport([Required]int reportDetailId)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = UserReport.DeleteLapTestPreport(reportDetailId);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("DeleteLabTestReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion

        [HttpGet, Route("generatePDFReport")]
        public IActionResult generatePDFReport([Required]int userId)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                string url = "";
                string filename = "HealthReport" + "-" + userId +"-"+ DateTime.Now.ToString("dd'-'MM'-'yyyy'-'HH'-'mm'-'ss") + ".pdf";
                //var  HtmlContent = UserReport.GetHTMLString(userId);


                //byte[] byteArray = Encoding.UTF8.GetBytes(HtmlContent);
                //MemoryStream stream = new MemoryStream(byteArray);


                //Document document = new Document(stream, new HtmlLoadOptions());
                //document.Save(filename);

                 var result = UserReport.GetHTMLString(userId);

                if(result == "Report not available for this user")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { status= result , url = url});

                }
                else
                {

               
                var globalSettings = new GlobalSettings
                {
                    ColorMode = ColorMode.Color,
                    Orientation = Orientation.Portrait,
                    PaperSize = PaperKind.A4,
                    Margins = new MarginSettings { Top = 12 },
                    DocumentTitle = "Health Care Report",
                    Out = filename,

                };
                var objectSettings = new ObjectSettings
                {
                    PagesCount = true,
                    HtmlContent = result,
                    WebSettings = { DefaultEncoding = "utf-8", /*UserStyleSheet = Path.Combine(Directory.GetCurrentDirectory(), "Assets", "styles.css")*/ },
                    HeaderSettings = {Line = true },
                    FooterSettings = { FontName = "Arial", FontSize = 9, Center = "Page [page] of [toPage]", Line = true },
                    //FooterSettings = { FontName = "Arial", FontSize = 9, Line = true, Center = "Report Footer" }
                };
                var pdf = new HtmlToPdfDocument()
                {
                    GlobalSettings = globalSettings,
                    Objects = { objectSettings }
                };
                _converter.Convert(pdf);



                    url = UploadFileBl.uploadFileFromPath(filename).Result;

                if ((System.IO.File.Exists(filename)))
                {

                    System.IO.File.Delete(filename);
                }
                    return StatusCode((int)HttpStatusCode.OK, new { status = "Success", url = url });

                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("generatePDFReport", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

    }
}