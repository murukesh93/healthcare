﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AllergiesController : ControllerBase
    {

        #region listAllergiesDetails
        /// <summary>
        /// To list all the Allergie Details
        /// </summary>
        [HttpGet, Route("listAllergiesDetails")]
        public IActionResult listAllergiesDetails(string search, int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(AllergiesBL.listAllergiesDetails(search, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listAllergiesDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region SaveAllergiesDetails
        /// <summary>
        /// To save user selected Allergies Details
        /// </summary>
        [HttpPost, Route("SaveAllergiesDetails")]
        [AllowAnonymous]
        public IActionResult SaveAllergiesDetails(SaveAllergies theobj)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result =AllergiesBL.SaveAllergiesDetails(theobj);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("SaveAllergiesDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region listUserSurgeriesTherapies
        /// <summary>
        /// To select user entered Allergies Details
        /// </summary>
        [HttpGet, Route("getUserAllergiesDetails")]
        public IActionResult getUserAllergiesDetails([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(AllergiesBL.getUserAllergiesDetails(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getUserAllergiesDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
    }
}