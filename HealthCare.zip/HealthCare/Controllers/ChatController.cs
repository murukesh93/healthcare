﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ChatController : ControllerBase
    {
        #region CreateChat
        /// <summary>
        /// To Create Chat
        /// </summary>
        [HttpPost, Route("CreateChat")]
        [AllowAnonymous]
        public IActionResult CreateChat(createChat createChat)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.createChat(createChat);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spCreateChat", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region CreateGroup
        /// <summary>
        /// To Create Chat Group
        /// </summary>
        [HttpPost, Route("CreateGroup")]
        [AllowAnonymous]
        public IActionResult CreateGroup(CreateGroup createGroup)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.CreateGroup(createGroup);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spCreateGroup", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region AddGroupMembers
        /// <summary>
        /// To  Add GroupMembers
        /// </summary>
        [HttpPost, Route("AddGroupMembers")]
        [AllowAnonymous]
        public IActionResult AddGroupMembers(AddGroupMembers addGroupMembers)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.AddGroupMembers(addGroupMembers);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spAddGroupMembers", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region UpdateSingleUserChatStatus
        /// <summary>
        /// To Update SingleUserChatStatus
        /// </summary>
        [HttpPut, Route("UpdateSingleUserChatStatus")]
        public IActionResult UpdateSingleUserChatStatus([FromBody]UpdateUserChatStatus updateUserChatStatus)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.UpdateSingleUserChatStatus(updateUserChatStatus);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion  

        #region UpdateGroupUserChatStatus
        /// <summary>
        /// To Update GroupUserChatStatus
        /// </summary>
        [HttpPut, Route("UpdateGroupUserChatStatus")]
        public IActionResult UpdateGroupUserChatStatus([FromBody]UpdateUserChatStatus updateUserChatStatus)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.UpdateGroupUserChatStatus(updateUserChatStatus);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region DeleteSingleContactList
        /// <summary>
        /// To Delete SingleContactList
        /// </summary>
        [HttpDelete, Route("DeleteSingleContactList")]
        public IActionResult DeleteSingleContactList([FromBody]DeleteContactList deleteContactList)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.DeleteSingleContactList(deleteContactList);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion  

        #region DeleteGroupContactList
        /// <summary>
        /// To Delete GroupContactList
        /// </summary>
        [HttpDelete, Route("DeleteGroupContactList")]
        public IActionResult DeleteGroupContactList([FromBody]DeleteContactList deleteContactList)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.DeleteGroupContactList(deleteContactList);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region DeleteGroup
        /// <summary>
        /// To Delete Group
        /// </summary>
        [HttpDelete, Route("DeleteGroup")]
        public IActionResult DeleteGroup([FromBody]DeleteGroup deleteGroup)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.DeleteGroup(deleteGroup);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion  

        #region ListChatList
        /// <summary>
        /// To list all the ChatList
        /// </summary>
        [HttpGet, Route("ListChatList")]
        public IActionResult ListChatList([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListChatList(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spListChatList", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region sendMessage
        /// <summary>
        /// To sendMessage
        /// </summary>
        [HttpPost, Route("sendMessage")]
        [AllowAnonymous]
        public IActionResult sendMessage(SendMessage sendMessage)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.sendMessage(sendMessage);

                if (result is string)
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spCreateChat", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region Delete Message
        /// <summary>
        /// To Delete Message
        /// </summary>
        [HttpDelete, Route("DeleteMessage")]
        public IActionResult DeleteMessage([Required] int chatMessageId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.DeleteMessage(chatMessageId);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion  

        #region ListChatList
        /// <summary>
        /// To list all the SingleChatMessage
        /// </summary>
        [HttpGet, Route("ListSingleChatMessage")]
        public IActionResult ListSingleChatMessage([Required]int userId, [Required]int chatcontactId, string search)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListSingleChatMessage(userId, chatcontactId, search));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spListSingleChatMessage", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region ListChatList
        /// <summary>
        /// To list all the GroupChatMessage
        /// </summary>
        [HttpGet, Route("ListGroupChatMessage")]
        public IActionResult ListGroupChatMessage([Required]int userId, [Required]int groupId, string search)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListGroupChatMessage(userId, groupId, search));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spListSingleChatMessage", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region sharePost
        /// <summary>
        /// To sharePost
        /// </summary>
        [HttpPost, Route("sharePost")]
        [AllowAnonymous]
        public IActionResult sharePost(SharePost sharePost)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.sharePost(sharePost);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spSharePost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region LikePost
        /// <summary>
        /// To LikePost
        /// </summary>
        [HttpPost, Route("LikePost")]
        [AllowAnonymous]
        public IActionResult LikePost(LikePost likePost)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.LikePost(likePost);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spLikePost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region commentPost
        /// <summary>
        /// To commentPost
        /// </summary>
        [HttpPost, Route("commentPost")]
        [AllowAnonymous]
        public IActionResult commentPost(commentPost commentPost)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.commentPost(commentPost);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spcommentPost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region ListPost
        /// <summary>
        /// To list all the Post
        /// </summary>
        [HttpGet, Route("ListPost")]
        public IActionResult ListPost([Required]int contactId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListPost(contactId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spListPost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region ListComment
        /// <summary>
        /// To list all the Comment
        /// </summary>
        [HttpGet, Route("ListComment")]
        public IActionResult ListComment([Required]int linkedInPostId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListComment(linkedInPostId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ListComment", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region getUserList
        /// <summary>
        /// To get UserList
        /// </summary>
        [HttpGet, Route("getUserList")]
        public IActionResult getUserList([Required]int userId, string search)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.getUserList(userId, search));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("spgetUserList", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
        #region getUserPost
        /// <summary>
        /// To get User Post
        /// </summary>
        [HttpGet, Route("getUserPost")]
        public IActionResult getUserPost([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.getUserPost(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getUserPost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getGroupList
        /// <summary>
        /// To get GroupList
        /// </summary>
        [HttpGet, Route("getGroupList")]
        public IActionResult getGroupList([Required]int groupId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.getGroupList(groupId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getGroupList", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region ListContactList
        /// <summary>
        /// To list all the contacts
        /// </summary>
        [HttpGet, Route("ListContactList")]
        public IActionResult ListContactList([Required]int userId, int groupId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.ListContactList(userId, groupId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ListContactList", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region DeletePost
        /// <summary>
        /// To  DeletePost
        /// </summary>
        [HttpDelete, Route("DeletePost")]
        public IActionResult DeletePost([Required] int linkedInPostId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.DeletePost(linkedInPostId);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("DeletePost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion



        #region ViewPost
        /// <summary>
        /// To  ViewPost
        /// </summary>
        [HttpPost, Route("ViewPost")]
        public IActionResult ViewPost(ViewPost viewPost)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.ViewPost(viewPost);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ViewPost", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region ViewPostComments
        /// <summary>
        /// To  ViewPostComments
        /// </summary>
        [HttpPost, Route("ViewPostComments")]
        public IActionResult ViewPostComments(ViewPostComment viewPostComment)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.ViewPostComments(viewPostComment);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ViewPostComments", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region clearChatNotification
        /// <summary>
        /// To clear chat notification
        /// </summary>
        [HttpPut, Route("clearChatNotification")]
        public IActionResult clearChatNotification([Required] int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.clearChatNotification(userId);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = "Error occured clear chat notification" });
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("clearChatNotification", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region getChatNotification
        /// <summary>
        /// To list all chat notification
        /// </summary>
        [HttpGet, Route("getChatNotification")]
        public IActionResult getChatNotification([Required]int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(Chat.getChatNotification(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getChatNotification", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region ViewProfile
        /// <summary>
        /// To ViewProfile
        /// </summary>
        [HttpPost, Route("ViewProfile")]
        public IActionResult ViewProfile(ViewProfile viewProfile)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = Chat.ViewProfile(viewProfile);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("ViewProfile", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion

        #region GetViewProfileUsers
        /// <summary>
        /// To GetViewProfileUsers
        /// </summary>
        [HttpGet, Route("GetViewProfileUsers")]
        public IActionResult GetViewProfileUsers([Required]int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(Chat.GetViewProfileUsers(userId));


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("GetViewProfileUsers", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion



    }
}