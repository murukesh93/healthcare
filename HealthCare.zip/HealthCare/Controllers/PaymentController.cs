﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.Model;
using HealthCare.BL;
using System.Net;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PaymentController : ControllerBase
    {
        #region savePaymentDetails
        /// <summary>
        /// To save Payment Details
        /// </summary>
        [HttpPost, Route("savePaymentDetails")]
        public IActionResult savePaymentDetails(Payment py)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(PaymentBL.savePaymentDetails(py));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("savePaymentDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region getPaymentHistory
        /// <summary>
        ///To get payment history
        /// </summary>
        [HttpGet, Route("getPaymentHistory")]
        public IActionResult getPaymentHistory([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(PaymentBL.getPaymentHistory(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getPaymentHistory", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getPlans
        /// <summary>
        ///To get Plans
        /// </summary>
        [HttpGet, Route("getPlans")]
        public IActionResult getPlans()
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(PaymentBL.getPlans());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getPlans", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getCurrentUserPlan
        /// <summary>
        ///To get current user plan
        /// </summary>
        [HttpGet, Route("getCurrentUserPlan")]
        public IActionResult getCurrentUserPlan([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(PaymentBL.getCurrentUserPlan(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getCurrentUserPlan", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion



    }
}