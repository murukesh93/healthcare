﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.BL;
using HealthCare.Data;
using HealthCare.Models;
using static HealthCare.Data.Common;
using System.ComponentModel.DataAnnotations;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadFileController : ControllerBase
    {
        #region uploadFile
        /// <summary>
        /// To uploadFile image for mobile
        /// </summary>
        [HttpPost, Route("uploadFile")]
        [AllowAnonymous]
        public IActionResult uploadFile( IFormFile formFile)
        {   
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                IFormFile myFile = Request.Form.Files.First();

                var result =  UploadFileBl.uploadFile(myFile).Result;
                return StatusCode((int)HttpStatusCode.OK, new { fileUrl = result });
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("uploadFile", e.Message.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }

        #endregion

    }
}