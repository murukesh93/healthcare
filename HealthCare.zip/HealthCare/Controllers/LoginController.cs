﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.Data;
using HealthCare.Models;
using HealthCare.BL;
using HealthCare.Model;

namespace HealthCare.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        #region login 
        /// <summary>
        /// 
        /// To Login
        /// </summary>
        // GET api/values
        [HttpPost, Route("login")]
        public IActionResult login([FromBody]Login login)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = LoginBL.login(login);

                if (Convert.ToString(result) == "Password and Username Mismatch")
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, new { ErrorMessage = "Invalid email or password" });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.OK,  result );
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("login", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region Provider login 
        /// <summary>
        /// To Login
        /// </summary>
        // GET api/values
        [HttpPost, Route("Providerlogin")]
        public IActionResult providerlogin([FromBody]ProviderLogin providerLogin)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = LoginBL.providerlogin(providerLogin);
                if (result != null)
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, new { ErrorMessage = "User not found" });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("login", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

    }
}