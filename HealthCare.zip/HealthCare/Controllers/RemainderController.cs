﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static HealthCare.Model.RemainderModel;

namespace HealthCare.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RemainderController : ControllerBase
    {

        #region createRemainder 
        /// <summary>
        /// 
        /// To create reamainder for user
        /// </summary>
        [HttpPost, Route("createRemainder")]
        public IActionResult createRemainder([FromBody]Remainder remainder)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = RemainderBL.createRemainder(remainder);

                if (result == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Remainder Created Successfully" });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result});
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveRemainder", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region updateRemainder 
        /// <summary>
        /// 
        /// To updat reamainder for user
        /// </summary>
        [HttpPost, Route("updateRemainder")]
        public IActionResult updateRemainder([FromBody]UpdateRemainder remainder)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = RemainderBL.updateRemainder(remainder);

                if (result == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { message = "Remainder Updated Successfully" });
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateRemainder", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region getRemainderListById
        /// <summary>
        /// To  select RemainderListById
        /// </summary>
        [HttpGet, Route("getRemainderListById")]
        public IActionResult getRemainderListById([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(RemainderBL.getRemainderListById(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getRemainderListById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
        #region getAllRemainderListById
        /// <summary>
        /// To  select all RemainderListById
        /// </summary>
        [HttpGet, Route("getAllRemainderListById")]
        public IActionResult getAllRemainderListById([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(RemainderBL.getAllRemainderListById(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getAllRemainderListById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion 
        #region getTimeZone
        /// <summary>
        /// To  get TimeZone
        /// </summary>
        [HttpGet, Route("getTimeZone")]
        public IActionResult getTimeZone()
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(RemainderBL.getTimeZone());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getTimeZone", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
      #endregion 


        #region getRemainderById
        /// <summary>
        /// To   get RemainderById
        /// </summary>
        [HttpGet, Route("getRemainderById")]
        public IActionResult getRemainderById([Required] int remainderId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(RemainderBL.getRemainderById(remainderId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getRemainderById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region DeleteRemainder
        /// <summary>
        /// To  DeleteRemainder
        /// </summary>
        [HttpDelete, Route("DeleteRemainder")]
        public IActionResult DeleteRemainder([Required] int remainderId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = RemainderBL.DeleteRemainder(remainderId);
                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }

            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });

            }
        }
        #endregion  
    }
}