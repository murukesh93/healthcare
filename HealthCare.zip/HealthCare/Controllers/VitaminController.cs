﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using HealthCare.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.Model;
using System.ComponentModel.DataAnnotations;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class VitaminController : ControllerBase
    {


        #region listVitaminDetails
        /// <summary>
        /// To list all the Vitamin Details
        /// </summary>
        [HttpGet, Route("listVitaminDetails")]
        public IActionResult listVitaminDetails(string search, int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(VitaminBL.listVitaminDetails(search, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listVitaminDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region SaveVitaminDetails
        /// <summary>
        /// To save user selected Vitamin Details
        /// </summary>
        [HttpPost, Route("SaveVitaminDetails")]
        [AllowAnonymous]
        public IActionResult SaveVitaminDetails(SaveVitamins theobj)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = VitaminBL.SaveVitaminDetails(theobj);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, new { ErrorMessage = result.message });
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("SaveVitaminDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region listUserSurgeriesTherapies
        /// <summary>
        /// To select user entered Vitamin Details
        /// </summary>
        [HttpGet, Route("getUserVitaminDetails")]
        public IActionResult getUserVitaminDetails([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(VitaminBL.getUserVitaminDetails(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getUserVitaminDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion
    }
}