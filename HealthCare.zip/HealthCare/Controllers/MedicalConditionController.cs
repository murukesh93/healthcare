﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.Model;
using HealthCare.BL;
using System.Net;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class MedicalConditionController : ControllerBase
    {
        #region saveMedicalCondition
        /// <summary>
        /// To save user medical condition 
        /// </summary>
        [HttpPost, Route("saveMedicalCondition")]
        [AllowAnonymous]
        public IActionResult saveMedicalCondition(SaveMedicalCondition med )
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result =MedicalConditionBL.saveMedicalCondition(med);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveMedicalCondition", e.Message);
               
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion

        #region listUserMedicalCondition
        /// <summary>
        /// To  select UserById
        /// </summary>
        [HttpGet, Route("listUserMedicalCondition")]
        public IActionResult listUserMedicalCondition([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(MedicalConditionBL.listUserMedicalCondition(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listUserMedicalCondition", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region listMedicalCondition
        /// <summary>
        /// To  list all the MedicalCondition
        /// </summary>
        [HttpGet, Route("listMedicalCondition")]
        public IActionResult listMedicalCondition(string search, int userId, int familyMedicalHistoryId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(MedicalConditionBL.listMedicalCondition(search, userId, familyMedicalHistoryId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listMedicalCondition", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region listFamilyMedicalCondition
        /// <summary>
        /// To  select UserById
        /// </summary>
        [HttpGet, Route("listFamilyMedicalCondition")]
        public IActionResult listFamilyMedicalCondition([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(MedicalConditionBL.listFamilyMedicalCondition(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listFamilyMedicalCondition", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }
        #endregion


        #region  saveFamilyMedicalCondition
        /// <summary>
        /// To save user medical condition 
        /// </summary>
        [HttpPost, Route("saveFamilyMedicalCondition")]
        [AllowAnonymous]
        public IActionResult saveFamilyMedicalCondition(SaveFamilyMedicalCondition med)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = MedicalConditionBL.saveFamilyMedicalCondition(med);

                if (result.message == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }

                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, new { ErrorMessage = result.message });
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveMedicalCondition", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message });
            }
        }

        #endregion
    }
}