﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Model
{
    public class createChat
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public int contactUserId { get; set; }
    }

    public class CreateGroup
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string groupName { get; set; }
        public string groupIcon { get; set; }
        public string groupMemberId { get; set; }
    }

    public class AddGroupMembers
    {
        [Required]
        public int groupId { get; set; }
        [Required]
        public string groupMemberId { get; set; }
    }

    public class UpdateUserChatStatus
    {
        [Required]
        public int userId { get; set; }
        public int contactUserId { get; set; }
        public string status { get; set; }
    }

    public class DeleteContactList
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string contactUserId { get; set; }
    }

    public class DeleteGroup
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public int groupId { get; set; }
    }

    public class SendMessage
    {
       
        public string chatType { get; set; }
        public int referenceId { get; set; }
        public string messageContent { get; set; }
        public string mediaContent { get; set; }
        public int? parentId { get; set; }
    }

    public class SharePost
    {
        public int contactId { get; set; }
        public string messageContent { get; set; }
        public string mediaContent { get; set; }
        public bool isAllowPublic { get; set; }
    }

    public class LikePost
    {
        public int linkedInPostId { get; set; }
        public int chatcontactId { get; set; }
        public bool isLiked { get; set; }
    }

    public class commentPost
    {
        public int linkedInPostId { get; set; }
        public int chatcontactId { get; set; }
        public string comments { get; set; }
        public string mediaContent { get; set; }
        public int? parentId { get; set; }
    }
    public class ViewPost
    {   [Required]
        public int linkedInPostId { get; set; }
        [Required]
        public int userId { get; set; }
    }
    public class ViewPostComment
    {
        [Required]
        public int postCommentId { get; set; }
        [Required]
        public int userId { get; set; }
    }

    public class ViewProfile
    {
        [Required]
        public int viewedUserId { get; set; }
        [Required]
        public int userId { get; set; }
    }
}