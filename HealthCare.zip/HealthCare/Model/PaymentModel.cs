﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Model
{
    public class Payment
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public int planId { get; set; }
        [Required]
        public decimal amount { get; set; }

        
    }
}
