﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Model
{
    public class SaveAllergies
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string allergieDetails { get; set; }
    }
}
