﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HealthCare.Model;
using HealthCare.BL;
using System.Net;

namespace HealthCare.Model
{

    public class SaveUserReports
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public decimal reportValue { get; set; }
        [Required]
        public int labtestId { get; set; }

        [Required]
        public int unitId { get; set; }

        public string reportDate { get; set; }

 
    }

    public class SaveUserDashBoardReports
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public decimal reportValue { get; set; }
        [Required]
        public int unitId { get; set; }


    }

    public class SaveUserBloodPressure
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public decimal systolicValue { get; set; }
        [Required]
        public decimal diastolicValue { get; set; }


    }
    public class DailyReports
    {
        public int dailyReport { get; set; }
     
        public float reportValue { get; set; }
    }
    public class WeeklyReports
    {
        public int weeklyReport { get; set; }
      
        public float reportValue { get; set; }
    }
    public class MonthlyReports
    {
        public int monthlyReport { get; set; }
    
        public float reportValue { get; set; }
    }
    public class Glucose
    {
        [Required]
        public int userReportId { get; set; }

        public float reportValue { get; set; }
    }

    public class BloodPressure
    {
        [Required]
        public int userReportId { get; set; }

        public float systolicValue { get; set; }
        public float diastolicValue { get; set; }
    }

    public class LapTestReport
    {
        [Required]
        public int reportDetailId { get; set; }

        public float reportValue { get; set; }
        public string reportDate { get; set; }
    }
}
