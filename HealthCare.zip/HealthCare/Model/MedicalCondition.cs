﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace HealthCare.Model
{
    public class SaveMedicalCondition
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string medicalCondition { get; set; }
    }
    public class SaveFamilyMedicalCondition
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string medicalCondition { get; set; }
        [Required]
        public int familyMedicalHistoryId { get; set; }
        [Required]
        public string memberName { get; set; }
        
        public string relationship { get; set; }

    }

}
