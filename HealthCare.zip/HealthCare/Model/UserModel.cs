﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Model
{
   


        public class Login
        {
            public string email { get; set; }
            public string password { get; set; }
        }
        public class ProviderLogin
        {
            public string loginProviderKey { get; set; }
            public string email { get; set; }
            public string name { get; set; }
        }
      
    public class ForgetPassword
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string password { get; set; }
    }
    public class User
    { 
        public string name { get; set; }
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }
        public string timeZone { get; set; }

    }
    public class UpdateUser
    {
        [Required]
        public int userId { get; set; }
        public string gender { get; set; }
        public string name { get; set; }
        public string dob { get; set; } 
        public int? bloodGroup { get; set; }
        public string height { get; set; }
        public string weight { get; set; }
        public int? country { get; set; }
        public string phoneNumber { get; set; }
        public string profileImage { get; set; }

        public string securityAnswer { get; set; }
        public string heightUnit { get; set; }
        public string weightUnit { get; set; }
        public string timeZone { get; set; }
    }

    public class SecurityQuestion
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string answer { get; set; }
    }

    public class userDevice
    {
        [Required]
        public int? userId { get; set; }
        [Required]
        public string deviceId { get; set; }
    }
}
