﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Model
{
    public class RemainderModel
    {
        public class Remainder
        {
            [Required]
            public int userId { get; set; }
            [Required]
            public int referenceId { get; set; }
            [Required]
            public string referenceType { get; set; }

            public string notes { get; set; }
            public string timeZone { get; set; }
            public string refillDate { get; set; }
            [Required]
            public string fromDate { get; set; }
            public string toDate { get; set; }
            public string remainderTime { get; set; }
            public bool isNoEndDate { get; set; }
            public bool isNoEndDateForRefill { get; set; }

            public int remindRefillDay { get; set; }


        }
        public class UpdateRemainder
        {
            [Required]
            public int remainderId { get; set; }
            [Required]
            public int? referenceId { get; set; }
            [Required]
            public string referenceType { get; set; }
            public string notes { get; set; }
            public string timeZone { get; set; }
            public string refillDate { get; set; }
            public string fromDate { get; set; }
            public string toDate { get; set; }
            public string remainderTime { get; set; }
            public bool isNoEndDate { get; set; }
            public bool isNoEndDateForRefill { get; set; }
            public int remindRefillDay { get; set; }


        }
    }
}
